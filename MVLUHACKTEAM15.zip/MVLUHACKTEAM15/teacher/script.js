// LOGIN LOGIC (inside teacher folder)
function loginUser(event) {
  event.preventDefault();

  const username = document.getElementById("username").value.trim();
  const role = document.getElementById("role").value;

  if (!username) {
    alert("Please enter your username.");
    return;
  }

  // Save session
  localStorage.setItem("username", username);
  localStorage.setItem("role", role);

  // Redirect properly based on role
  if (role === "teacher") {
    window.location.href = "dashboard.html";   // teacher dashboard (inside this folder)
  } else {
    window.location.href = "../dashboard.html"; // go back to student dashboard
  }
}

// DASHBOARD LOGIC
window.addEventListener("DOMContentLoaded", () => {
  const userName = localStorage.getItem("username");
  const role = localStorage.getItem("role");

  if (!userName) {
    window.location.href = "../index.html"; // not logged in
    return;
  }

  if (document.getElementById("userName")) {
    document.getElementById("userName").textContent = userName;
  }

  if (role === "teacher") {
    // Teacher dashboard specific
    if (document.getElementById("teacherContent")) {
      document.getElementById("teacherContent").style.display = "block";
    }
    if (document.getElementById("studentContent")) {
      document.getElementById("studentContent").style.display = "none";
    }
    if (document.getElementById("teacherName")) {
      document.getElementById("teacherName").textContent = userName;
    }
  } else {
    // If a student somehow ends up here, kick them back
    window.location.href = "../dashboard.html";
  }
});

// LOGOUT
function logout() {
  localStorage.clear();
  window.location.href = "../index.html";
}
