// LOGIN FUNCTION
function loginUser(event) {
  event.preventDefault();
  let username = document.getElementById("username").value.trim();
  let role = document.getElementById("role").value; // dropdown or radio for student/teacher

  if (username === "") {
    alert("Please enter a username!");
    return false;
  }

  // Save to localStorage
  localStorage.setItem("username", username);
  localStorage.setItem("role", role);

  // Redirect based on role
  if (role === "teacher") {
    window.location.href = "teacher/dashboard.html";  // 👈 go to teacher folder
  } else {
    window.location.href = "dashboard.html";         // 👈 student dashboard
  }
}

// DASHBOARD LOAD
window.onload = function() {
  if (window.location.pathname.includes("dashboard.html")) {
    let username = localStorage.getItem("username");
    let role = localStorage.getItem("role");

    if (!username) {
      window.location.href = "index.html"; // not logged in
    }

    // Display username
    if (document.getElementById("userName")) {
      document.getElementById("userName").textContent = username;
    }

    // Role-based content
    if (role === "student") {
      let studentContent = document.getElementById("studentContent");
      let teacherContent = document.getElementById("teacherContent");

      if (studentContent) studentContent.style.display = "block";
      if (teacherContent) teacherContent.style.display = "none";
    } else if (role === "teacher") {
      let studentContent = document.getElementById("studentContent");
      let teacherContent = document.getElementById("teacherContent");

      if (studentContent) studentContent.style.display = "none";
      if (teacherContent) teacherContent.style.display = "block";
    }
  }
};

// LOGOUT
function logout() {
  localStorage.clear();
  window.location.href = "index.html";
}





let currentChatUser = null;

// Open chat with selected contact
function openChat(contactName) {
  currentChatUser = contactName;
  document.getElementById("chatHeader").textContent = "Chat with " + contactName;
  loadMessages(contactName);
}

// Load messages from localStorage
function loadMessages(contact) {
  let chatBox = document.getElementById("chatBox");
  chatBox.innerHTML = "";

  let messages = JSON.parse(localStorage.getItem("messages_" + contact)) || [];

  messages.forEach(msg => {
    let div = document.createElement("div");
    div.classList.add("message", msg.sender === "me" ? "sent" : "received");
    div.textContent = msg.text;
    chatBox.appendChild(div);
  });

  chatBox.scrollTop = chatBox.scrollHeight;
}

// Send message
function sendMessage() {
  let input = document.getElementById("messageInput");
  let text = input.value.trim();

  if (text && currentChatUser) {
    let messages = JSON.parse(localStorage.getItem("messages_" + currentChatUser)) || [];

    // Add my message
    messages.push({ sender: "me", text });
    localStorage.setItem("messages_" + currentChatUser, JSON.stringify(messages));

    input.value = "";
    loadMessages(currentChatUser);
  }
}









// Course filtering
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  const categoryFilter = document.getElementById("categoryFilter");
  const levelFilter = document.getElementById("levelFilter");
  const courses = document.querySelectorAll(".course-card");

  function filterCourses() {
    const search = searchInput.value.toLowerCase();
    const category = categoryFilter.value;
    const level = levelFilter.value;

    courses.forEach(course => {
      const title = course.querySelector("h3").innerText.toLowerCase();
      const desc = course.querySelector("p").innerText.toLowerCase();
      const courseCat = course.dataset.category;
      const courseLvl = course.dataset.level;

      const matchesSearch = title.includes(search) || desc.includes(search);
      const matchesCategory = (category === "all" || category === courseCat);
      const matchesLevel = (level === "all" || level === courseLvl);

      if (matchesSearch && matchesCategory && matchesLevel) {
        course.style.display = "block";
      } else {
        course.style.display = "none";
      }
    });
  }

  searchInput.addEventListener("input", filterCourses);
  categoryFilter.addEventListener("change", filterCourses);
  levelFilter.addEventListener("change", filterCourses);
});











// Sample assignments uploaded by teachers
const assignments = [
  { title: "Math Homework 1", description: "Solve all questions in Chapter 2.", teacher: "Dr. Emily Chen" },
  { title: "Physics Lab Report", description: "Complete the mechanics experiment report.", teacher: "Dr. Michael Lee" },
  { title: "Web Development Project", description: "Build a portfolio website.", teacher: "Jane Doe" }
];

// Load assignments
function loadAssignments() {
  const list = document.getElementById("assignmentList");
  list.innerHTML = "";
  assignments.forEach((a, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<b>${a.title}</b> by ${a.teacher}<br>${a.description}`;
    list.appendChild(li);
  });
}

// Submit assignment
function submitAssignment() {
  const title = document.getElementById("assignmentTitle").value.trim();
  const file = document.getElementById("assignmentFile").files[0];
  const notes = document.getElementById("assignmentNotes").value.trim();
  if (!title || !file) {
    alert("Please enter title and select a file!");
    return;
  }

  const submissions = JSON.parse(localStorage.getItem("submissions")) || [];
  submissions.push({ title, fileName: file.name, notes, grade: "Pending", feedback: "No feedback yet" });
  localStorage.setItem("submissions", JSON.stringify(submissions));

  document.getElementById("assignmentTitle").value = "";
  document.getElementById("assignmentFile").value = "";
  document.getElementById("assignmentNotes").value = "";

  loadSubmissions();
}

// Load submissions
function loadSubmissions() {
  const list = document.getElementById("submissionList");
  list.innerHTML = "";
  const submissions = JSON.parse(localStorage.getItem("submissions")) || [];

  submissions.forEach(sub => {
    const li = document.createElement("li");
    li.innerHTML = `<b>${sub.title}</b> (${sub.fileName})<br>Notes: ${sub.notes}<br>Grade: ${sub.grade}<br>Feedback: ${sub.feedback}`;
    list.appendChild(li);
  });
}

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  loadAssignments();
  loadSubmissions();
});











// Queries: Post + Save
function postQuery() {
  let queryText = document.getElementById("queryText").value.trim();
  if (!queryText) return;

  let queries = JSON.parse(localStorage.getItem("queries")) || [];
  queries.push({ user: localStorage.getItem("username"), text: queryText });
  localStorage.setItem("queries", JSON.stringify(queries));

  document.getElementById("queryText").value = "";
  loadQueries();
}

function loadQueries() {
  let queryList = document.getElementById("queryList");
  if (!queryList) return;

  queryList.innerHTML = "";
  let queries = JSON.parse(localStorage.getItem("queries")) || [];

  queries.forEach(q => {
    let div = document.createElement("div");
    div.className = "query";
    div.innerHTML = `<b>${q.user}:</b> ${q.text}`;
    queryList.appendChild(div);
  });
}

// Auto load queries if on queries.html
if (window.location.pathname.includes("queries.html")) {
  loadQueries();
}














// ====== Sample Test Papers ======
const tests = [
  { title: "Math Sample Test", subject: "Math", description: "Algebra, Geometry, and Calculus questions." },
  { title: "Physics Sample Test", subject: "Science", description: "Mechanics and Thermodynamics." },
  { title: "Web Development Test", subject: "Computer Science", description: "HTML, CSS, JS basics." },
  { title: "English Grammar Test", subject: "Language", description: "Tenses, punctuation, and comprehension." },
  { title: "Art Appreciation Test", subject: "Art", description: "Famous artists and techniques." },
  { title: "Music Theory Test", subject: "Music", description: "Notes, scales, and rhythm." }
];

function loadTests() {
  const container = document.getElementById("testsContainer");
  if (!container) return;
  container.innerHTML = "";

  tests.forEach(test => {
    const div = document.createElement("div");
    div.className = "test-card";
    div.innerHTML = `
      <h3>${test.title}</h3>
      <p>Subject: ${test.subject}</p>
      <p>${test.description}</p>
      <button onclick="startTest('${test.title}')">Start Test</button>
    `;
    container.appendChild(div);
  });
}

// Placeholder start test function
function startTest(title) {
  alert(`Starting test: ${title}`);
}


// ====== Test Points Integration ======

// Points per test (you can adjust)
const testPoints = 15;

// Track completed tests in localStorage
function completeTest(title) {
  alert(`Test "${title}" completed! You earned ${testPoints} points.`);
  
  const username = localStorage.getItem("username") || "Student";
  
  // Save test points in localStorage leaderboard
  const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
  
  // Check if student already has a score entry for this test
  let studentEntry = leaderboard.find(e => e.user === username);
  if (!studentEntry) {
    studentEntry = { user: username, score: 0, timeTaken: 0 };
    leaderboard.push(studentEntry);
  }
  
  studentEntry.score += testPoints;
  // For simplicity, timeTaken = 0 for tests (can add timer later)
  
  localStorage.setItem("leaderboard", JSON.stringify(leaderboard));
  
  // Optional: update leaderboard live
  if (typeof renderLeaderboard === "function") renderLeaderboard();
}

// Update startTest to call completeTest
function startTest(title) {
  alert(`Starting test: ${title}`);
  
  // Simulate immediate completion for demo purposes
  completeTest(title);
}


// Initialize tests page
document.addEventListener("DOMContentLoaded", loadTests);














// ====== Mock Interview Questions ======
const interviewQuestions = [
  {
    category: "HR Questions",
    q: "Tell me about yourself.",
    a: "Keep it professional: highlight education, skills, and relevant experience. Keep it under 2 minutes."
  },
  {
    category: "HR Questions",
    q: "What are your strengths and weaknesses?",
    a: "Strengths: choose skills relevant to the role. Weaknesses: pick something minor and show how you’re improving it."
  },
  {
    category: "HR Questions",
    q: "Why should we hire you?",
    a: "Show how your skills, experience, and passion align with the company’s needs."
  },
  {
    category: "Behavioral Questions",
    q: "Describe a time when you faced a challenge at work and how you handled it.",
    a: "Use the STAR method (Situation, Task, Action, Result) to give a clear example."
  },
  {
    category: "Behavioral Questions",
    q: "Give an example of when you worked in a team.",
    a: "Highlight collaboration, communication, and achieving goals together."
  },
  {
    category: "Situational Questions",
    q: "What would you do if you had a conflict with a coworker?",
    a: "Show maturity: focus on communication, professionalism, and resolution."
  },
  {
    category: "Situational Questions",
    q: "How would you handle multiple deadlines?",
    a: "Mention prioritization, time management, and clear communication with stakeholders."
  },
  {
    category: "Technical Questions",
    q: "Explain the difference between frontend and backend development.",
    a: "Frontend = user interface (HTML, CSS, JS). Backend = server-side (databases, APIs, server logic)."
  },
  {
    category: "Technical Questions",
    q: "What is OOP (Object-Oriented Programming)?",
    a: "A programming paradigm based on objects containing data (fields) and methods. Key concepts: encapsulation, inheritance, polymorphism, abstraction."
  },
  {
    category: "Technical Questions",
    q: "What happens when you type a URL in the browser?",
    a: "Steps: DNS lookup, TCP/IP connection, HTTP request, server response, rendering HTML/CSS/JS."
  },
  {
    category: "General",
    q: "Where do you see yourself in 5 years?",
    a: "Show ambition but keep it realistic and aligned with the company’s growth."
  },
  {
    category: "General",
    q: "Do you have any questions for us?",
    a: "Always ask! Example: 'What does career growth look like in this company?'"
  }
];

function loadInterviewQuestions() {
  const container = document.getElementById("interviewContainer");
  if (!container) return;
  container.innerHTML = "";

  interviewQuestions.forEach(item => {
    const div = document.createElement("div");
    div.className = "interview-card";
    div.innerHTML = `
      <h3>${item.category}: ${item.q}</h3>
      <p class="answer">${item.a}</p>
    `;
    div.addEventListener("click", () => {
      div.classList.toggle("active");
    });
    container.appendChild(div);
  });
}

// Initialize
document.addEventListener("DOMContentLoaded", loadInterviewQuestions);
















// ====== CV Generator ======
document.addEventListener("DOMContentLoaded", () => {
  const cvForm = document.getElementById("cvForm");
  if (!cvForm) return;

  cvForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const linkedin = document.getElementById("linkedin").value;
    const github = document.getElementById("github").value;
    const education = document.getElementById("education").value;
    const experience = document.getElementById("experience").value;
    const skills = document.getElementById("skills").value;
    const projects = document.getElementById("projects").value;

    const cvPreview = document.getElementById("cvPreview");
    const cvOutput = document.getElementById("cvOutput");
    cvOutput.style.display = "block";

    cvPreview.innerHTML = `
      <h1>${name}</h1>
      <p><b>Email:</b> ${email} | <b>Phone:</b> ${phone}</p>
      <p><b>LinkedIn:</b> ${linkedin || "N/A"} | <b>GitHub:</b> ${github || "N/A"}</p>
      
      <h2>Education</h2>
      <p>${education || "Not provided"}</p>

      <h2>Experience</h2>
      <p>${experience || "Not provided"}</p>

      <h2>Skills</h2>
      <p>${skills || "Not provided"}</p>

      <h2>Projects</h2>
      <p>${projects || "Not provided"}</p>
    `;
  });
});







// ====== Communities Join Simulation ======
function joinCommunity(btn) {
  btn.innerText = "Joined ✅";
  btn.classList.add("joined");
  btn.disabled = true;

  // Later: store in localStorage to remember joined communities
}



