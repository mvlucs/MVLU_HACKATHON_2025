// Sample quiz questions
const quizQuestions = [
  {
    question: "What is the capital of France?",
    options: ["Paris", "London", "Berlin", "Madrid"],
    answer: "Paris",
    points: 10
  },
  {
    question: "Which language is primarily used for web development?",
    options: ["Python", "JavaScript", "C++", "Java"],
    answer: "JavaScript",
    points: 10
  },
  {
    question: "What does HTML stand for?",
    options: ["HyperText Markup Language", "HighText Machine Language", "Hyperlinks Text Mark Language", "None of the above"],
    answer: "HyperText Markup Language",
    points: 10
  }
];

const quizContainer = document.getElementById("quizContainer");
const submitBtn = document.getElementById("submitQuiz");
const scoreContainer = document.getElementById("scoreContainer");

// Load quiz
function loadQuiz() {
  quizContainer.innerHTML = "";
  quizQuestions.forEach((q, idx) => {
    const div = document.createElement("div");
    div.className = "quiz-question";
    div.innerHTML = `<h3>Q${idx + 1}: ${q.question}</h3>
      <div class="quiz-options">
        ${q.options.map(opt => `<label><input type="radio" name="q${idx}" value="${opt}"> ${opt}</label>`).join('')}
      </div>`;
    quizContainer.appendChild(div);
  });
}

// Calculate score
function submitQuiz() {
  let score = 0;
  const startTime = performance.now(); // optional timing feature

  quizQuestions.forEach((q, idx) => {
    const selected = document.querySelector(`input[name="q${idx}"]:checked`);
    if (selected && selected.value === q.answer) {
      score += q.points;
    }
  });

  const endTime = performance.now();
  const timeTaken = ((endTime - startTime)/1000).toFixed(2); // seconds

  scoreContainer.innerHTML = `Your score: ${score} / ${quizQuestions.reduce((a,b) => a+b.points,0)} <br> Time taken: ${timeTaken} seconds`;

  // Save score to localStorage for leaderboard
  const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
  leaderboard.push({ user: localStorage.getItem("username") || "Student", score, timeTaken });
  localStorage.setItem("leaderboard", JSON.stringify(leaderboard));
}

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  loadQuiz();
  submitBtn.addEventListener("click", submitQuiz);
});
