const container = document.getElementById("leaderboardContainer");

// Fetch quiz scores
const quizScores = JSON.parse(localStorage.getItem("leaderboard")) || [];

// Fetch student assignment scores
const submissions = JSON.parse(localStorage.getItem("submissions")) || [];

// Calculate total points per student
const totalScores = {};

// Add quiz points
quizScores.forEach(q => {
  if (!totalScores[q.user]) totalScores[q.user] = { total: 0, time: 0 };
  totalScores[q.user].total += q.score;
  totalScores[q.user].time += parseFloat(q.timeTaken);
});

// Add assignment points (example: 10 points per submitted assignment)
submissions.forEach(s => {
  const student = s.user || "Student"; // make sure each submission has a user
  if (!totalScores[student]) totalScores[student] = { total: 0, time: 0 };
  totalScores[student].total += 10; // fixed assignment points
});

// Convert to array and sort by total points, then time
const leaderboard = Object.keys(totalScores).map(user => ({
  user,
  total: totalScores[user].total,
  time: totalScores[user].time
}));

leaderboard.sort((a, b) => {
  if (b.total === a.total) return a.time - b.time;
  return b.total - a.total;
});

// Render leaderboard
function renderLeaderboard() {
  container.innerHTML = "";
  leaderboard.forEach((student, index) => {
    const card = document.createElement("div");
    card.className = "leaderboard-card";

    // Highlight top 3
    let highlight = "";
    if (index === 0) highlight = "gold";
    else if (index === 1) highlight = "silver";
    else if (index === 2) highlight = "bronze";

    card.style.border = highlight ? `2px solid ${highlight}` : "none";

    card.innerHTML = `
      <h3>Rank #${index + 1}: ${student.user}</h3>
      <p>Total Points: ${student.total}</p>
      <p>Time Bonus: ${student.time.toFixed(2)} seconds</p>
    `;
    container.appendChild(card);
  });
}

// Initialize
document.addEventListener("DOMContentLoaded", renderLeaderboard);
