-- Enable Row Level Security (RLS) for all tables
-- This ensures data security and proper access control

-- Enable RLS on all tables
ALTER TABLE disease_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE encyclopedia ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE crop_varieties ENABLE ROW LEVEL SECURITY;
ALTER TABLE soil_analysis ENABLE ROW LEVEL SECURITY;
ALTER TABLE schemes ENABLE ROW LEVEL SECURITY;
ALTER TABLE weather_data ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access (since this is an agricultural information app)
-- In a production environment, you might want more restrictive policies

-- Disease Reports - Allow read for all, insert for authenticated users
CREATE POLICY "Allow public read access on disease_reports" ON disease_reports
    FOR SELECT USING (true);

CREATE POLICY "Allow insert for authenticated users on disease_reports" ON disease_reports
    FOR INSERT WITH CHECK (true);

-- Encyclopedia - Allow public read access
CREATE POLICY "Allow public read access on encyclopedia" ON encyclopedia
    FOR SELECT USING (true);

-- Market Prices - Allow public read access
CREATE POLICY "Allow public read access on market_prices" ON market_prices
    FOR SELECT USING (true);

-- Crop Varieties - Allow public read access
CREATE POLICY "Allow public read access on crop_varieties" ON crop_varieties
    FOR SELECT USING (true);

-- Soil Analysis - Allow read for all, insert for authenticated users
CREATE POLICY "Allow public read access on soil_analysis" ON soil_analysis
    FOR SELECT USING (true);

CREATE POLICY "Allow insert for authenticated users on soil_analysis" ON soil_analysis
    FOR INSERT WITH CHECK (true);

-- Schemes - Allow public read access
CREATE POLICY "Allow public read access on schemes" ON schemes
    FOR SELECT USING (true);

-- Weather Data - Allow public read access
CREATE POLICY "Allow public read access on weather_data" ON weather_data
    FOR SELECT USING (true);

CREATE POLICY "Allow insert for system on weather_data" ON weather_data
    FOR INSERT WITH CHECK (true);
