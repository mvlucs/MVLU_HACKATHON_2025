-- Insert sample crops
INSERT INTO public.crops (name, variety, season, growth_duration) VALUES
('Rice', 'Basmati', 'Kharif', 120),
('Wheat', 'HD-2967', 'Rabi', 150),
('Cotton', 'Bt Cotton', 'Kharif', 180),
('Sugarcane', 'Co-86032', 'Annual', 365),
('Maize', 'Hybrid', 'Kharif', 90),
('Soybean', 'JS-335', 'Kharif', 100),
('Mustard', 'Varuna', 'Rabi', 120),
('Groundnut', 'TMV-2', 'Kharif', 110)
ON CONFLICT DO NOTHING;

-- Insert sample market prices
INSERT INTO public.market_prices (crop_name, price_per_kg, market_location, date_recorded) VALUES
('Rice', 25.50, 'Delhi Mandi', CURRENT_DATE),
('Wheat', 22.00, 'Punjab Mandi', CURRENT_DATE),
('Cotton', 55.00, 'Gujarat Mandi', CURRENT_DATE),
('Sugarcane', 3.50, 'UP Mandi', CURRENT_DATE),
('Maize', 18.00, 'MP Mandi', CURRENT_DATE),
('Soybean', 45.00, 'Maharashtra Mandi', CURRENT_DATE),
('Mustard', 52.00, 'Rajasthan Mandi', CURRENT_DATE),
('Groundnut', 65.00, 'Gujarat Mandi', CURRENT_DATE)
ON CONFLICT DO NOTHING;

-- Insert sample government schemes
INSERT INTO public.government_schemes (title, description, eligibility_criteria, benefits, application_process, deadline, is_active) VALUES
('PM-KISAN', 'Direct income support to farmers', 'Small and marginal farmers with cultivable land', 'Rs. 6000 per year in 3 installments', 'Apply online at pmkisan.gov.in', '2024-12-31', true),
('Crop Insurance Scheme', 'Insurance coverage for crop losses', 'All farmers growing notified crops', 'Coverage against natural calamities', 'Apply through banks or online', '2024-12-31', true),
('Soil Health Card', 'Soil testing and nutrient management', 'All farmers', 'Free soil testing and recommendations', 'Contact local agriculture office', NULL, true),
('Kisan Credit Card', 'Credit facility for farmers', 'Farmers with land records', 'Easy credit access at low interest', 'Apply at any bank branch', NULL, true)
ON CONFLICT DO NOTHING;

-- Insert sample encyclopedia entries
INSERT INTO public.encyclopedia (crop_name, scientific_name, description, planting_season, harvesting_time, soil_requirements, water_requirements, fertilizer_recommendations, common_diseases, market_demand) VALUES
('Rice', 'Oryza sativa', 'Rice is a staple food crop grown in flooded fields', 'June-July (Kharif)', '4-6 months after planting', 'Clay loam soil with good water retention', 'High water requirement, flooded conditions', 'NPK 120:60:40 kg/ha', 'Blast, Brown spot, Bacterial blight', 'High demand throughout the year'),
('Wheat', 'Triticum aestivum', 'Wheat is a major cereal grain and staple food', 'November-December (Rabi)', '4-5 months after planting', 'Well-drained loamy soil', 'Moderate water requirement', 'NPK 120:60:40 kg/ha', 'Rust, Smut, Powdery mildew', 'Consistent high demand'),
('Cotton', 'Gossypium hirsutum', 'Cotton is a major cash crop grown for fiber', 'May-June (Kharif)', '5-6 months after planting', 'Black cotton soil preferred', 'Moderate to high water requirement', 'NPK 120:60:60 kg/ha', 'Bollworm, Aphids, Whitefly', 'High demand in textile industry')
ON CONFLICT (crop_name) DO NOTHING;

-- Insert sample weather data
INSERT INTO public.weather_data (location, temperature, humidity, rainfall, wind_speed, weather_condition, date_recorded) VALUES
('Delhi', 28.5, 65.0, 0.0, 12.5, 'Partly Cloudy', CURRENT_DATE),
('Mumbai', 32.0, 78.0, 2.5, 15.0, 'Light Rain', CURRENT_DATE),
('Bangalore', 25.0, 60.0, 0.0, 8.0, 'Clear', CURRENT_DATE),
('Chennai', 30.0, 75.0, 1.0, 10.0, 'Cloudy', CURRENT_DATE),
('Kolkata', 29.0, 80.0, 5.0, 14.0, 'Heavy Rain', CURRENT_DATE)
ON CONFLICT DO NOTHING;
