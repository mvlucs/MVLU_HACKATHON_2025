import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Navbar from '@/components/Navbar';
import { mockKnowledgeBase } from '@/lib/mockData';
import { BookOpen, Search, Filter, Play, Download, MessageCircle, Star } from 'lucide-react';

export default function KnowledgeBase() {
  const [language, setLanguage] = useState('en');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { value: 'all', label: language === 'hi' ? 'सभी श्रेणियां' : 'All Categories' },
    { value: 'Soil Care', label: language === 'hi' ? 'मिट्टी की देखभाल' : 'Soil Care' },
    { value: 'Pest Control', label: language === 'hi' ? 'कीट नियंत्रण' : 'Pest Control' },
    { value: 'Water Management', label: language === 'hi' ? 'जल प्रबंधन' : 'Water Management' },
    { value: 'Crop Selection', label: language === 'hi' ? 'फसल चयन' : 'Crop Selection' }
  ];

  const filteredArticles = mockKnowledgeBase.filter(article => {
    const categoryMatch = selectedCategory === 'all' || article.category === selectedCategory;
    const searchMatch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       article.titleHi.includes(searchTerm) ||
                       article.content.toLowerCase().includes(searchTerm.toLowerCase());
    return categoryMatch && searchMatch;
  });

  const featuredVideos = [
    {
      title: language === 'hi' ? 'जैविक खेती की शुरुआत' : 'Getting Started with Organic Farming',
      duration: '15:30',
      views: '12.5K',
      thumbnail: '🎥',
      category: 'Organic Farming'
    },
    {
      title: language === 'hi' ? 'ड्रिप सिंचाई सिस्टम' : 'Drip Irrigation System Setup',
      duration: '22:15',
      views: '8.2K',
      thumbnail: '🎥',
      category: 'Water Management'
    },
    {
      title: language === 'hi' ? 'कीट पहचान गाइड' : 'Pest Identification Guide',
      duration: '18:45',
      views: '15.8K',
      thumbnail: '🎥',
      category: 'Pest Control'
    }
  ];

  const expertAdvice = [
    {
      expert: 'Dr. Rajesh Kumar',
      specialization: language === 'hi' ? 'मिट्टी विशेषज्ञ' : 'Soil Specialist',
      advice: language === 'hi' 
        ? 'मिट्टी की जांच हर 6 महीने में कराएं और जैविक खाद का उपयोग करें।'
        : 'Test your soil every 6 months and use organic fertilizers for best results.',
      rating: 4.8,
      consultations: 150
    },
    {
      expert: 'Dr. Priya Sharma',
      specialization: language === 'hi' ? 'फसल रोग विशेषज्ञ' : 'Crop Disease Expert',
      advice: language === 'hi' 
        ? 'नीम का तेल प्राकृतिक कीटनाशक के रूप में बहुत प्रभावी है।'
        : 'Neem oil is highly effective as a natural pesticide for most crops.',
      rating: 4.9,
      consultations: 200
    }
  ];

  const quickTips = [
    {
      tip: language === 'hi' ? 'सुबह जल्दी सिंचाई करें' : 'Water early in the morning',
      description: language === 'hi' 
        ? 'पानी की कम बर्बादी और बेहतर अवशोषण के लिए'
        : 'For less water wastage and better absorption'
    },
    {
      tip: language === 'hi' ? 'मिश्रित फसल उगाएं' : 'Practice intercropping',
      description: language === 'hi' 
        ? 'कीटों से प्राकृतिक सुरक्षा और बेहतर उत्पादन'
        : 'Natural pest protection and better yield'
    },
    {
      tip: language === 'hi' ? 'मिट्टी को ढकें' : 'Use mulching',
      description: language === 'hi' 
        ? 'नमी बनाए रखने और खरपतवार नियंत्रण के लिए'
        : 'To retain moisture and control weeds'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />
      
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? 'ज्ञान केंद्र' : 'Knowledge Center'}
          </h1>
          <p className="text-gray-600">
            {language === 'hi' 
              ? 'कृषि ज्ञान, विशेषज्ञ सलाह और सर्वोत्तम प्रथाओं का भंडार' 
              : 'Repository of agricultural knowledge, expert advice and best practices'
            }
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search and Filters */}
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-blue-600" />
                    {language === 'hi' ? 'लेख और गाइड' : 'Articles & Guides'}
                  </CardTitle>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder={language === 'hi' ? 'खोजें...' : 'Search...'}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-48"
                      />
                    </div>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredArticles.map((article) => (
                    <div key={article.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h3 className="font-medium mb-1">
                            {language === 'hi' ? article.titleHi : article.title}
                          </h3>
                          <p className="text-sm text-gray-600 mb-2">{article.content}</p>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary">
                              {language === 'hi' ? article.categoryHi : article.category}
                            </Badge>
                            {article.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          {language === 'hi' ? 'पढ़ें' : 'Read'}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Featured Videos */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5 text-red-600" />
                  {language === 'hi' ? 'फीचर्ड वीडियो' : 'Featured Videos'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {featuredVideos.map((video, index) => (
                    <div key={index} className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                      <div className="bg-gray-100 h-32 flex items-center justify-center">
                        <div className="text-center">
                          <span className="text-4xl">{video.thumbnail}</span>
                          <div className="mt-2">
                            <Play className="h-8 w-8 mx-auto text-red-600" />
                          </div>
                        </div>
                      </div>
                      <div className="p-3">
                        <h4 className="font-medium mb-1">{video.title}</h4>
                        <div className="flex items-center justify-between text-sm text-gray-500">
                          <span>{video.duration}</span>
                          <span>{video.views} views</span>
                        </div>
                        <Badge variant="outline" className="mt-2 text-xs">
                          {video.category}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Expert Advice */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5 text-green-600" />
                  {language === 'hi' ? 'विशेषज्ञ सलाह' : 'Expert Advice'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {expertAdvice.map((expert, index) => (
                  <div key={index} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{expert.expert}</h4>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500 fill-current" />
                        <span className="text-sm">{expert.rating}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{expert.specialization}</p>
                    <p className="text-sm mb-2">{expert.advice}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        {expert.consultations} {language === 'hi' ? 'परामर्श' : 'consultations'}
                      </span>
                      <Button size="sm" variant="outline">
                        {language === 'hi' ? 'संपर्क करें' : 'Contact'}
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'त्वरित सुझाव' : 'Quick Tips'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {quickTips.map((tip, index) => (
                  <div key={index} className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-medium text-green-800 mb-1">{tip.tip}</h4>
                    <p className="text-sm text-green-600">{tip.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Download Resources */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5 text-purple-600" />
                  {language === 'hi' ? 'डाउनलोड संसाधन' : 'Download Resources'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'फसल कैलेंडर PDF' : 'Crop Calendar PDF'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'कीट पहचान गाइड' : 'Pest ID Guide'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'जैविक खाद रेसिपी' : 'Organic Fertilizer Recipes'}
                </Button>
              </CardContent>
            </Card>

            {/* Popular Categories */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'लोकप्रिय श्रेणियां' : 'Popular Categories'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.slice(1).map((category) => (
                    <div key={category.value} className="flex items-center justify-between">
                      <span className="text-sm">{category.label}</span>
                      <Badge variant="secondary">
                        {mockKnowledgeBase.filter(a => a.category === category.value).length}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
