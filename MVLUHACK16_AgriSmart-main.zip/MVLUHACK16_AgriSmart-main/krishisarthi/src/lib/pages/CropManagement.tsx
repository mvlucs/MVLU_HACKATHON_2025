import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Navbar from '@/components/Navbar';
import CropCard from '@/components/CropCard';
import { mockCropsData } from '@/lib/mockData';
import { CROP_SEASONS } from '@/lib/constants';
import { Sprout, Plus, Filter, Calendar, TrendingUp } from 'lucide-react';

export default function CropManagement() {
  const [language, setLanguage] = useState('en');
  const [selectedSeason, setSelectedSeason] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  const filteredCrops = mockCropsData.filter(crop => {
    const seasonMatch = selectedSeason === 'all' || crop.season === selectedSeason;
    const statusMatch = selectedStatus === 'all' || crop.status.toLowerCase() === selectedStatus;
    return seasonMatch && statusMatch;
  });

  const cropStats = {
    total: mockCropsData.length,
    growing: mockCropsData.filter(c => c.status === 'Growing').length,
    harvested: mockCropsData.filter(c => c.status === 'Harvested').length,
    totalArea: mockCropsData.reduce((sum, c) => sum + c.area, 0)
  };

  const recommendedCrops = [
    {
      name: 'Mustard',
      nameHi: 'सरसों',
      season: 'rabi',
      suitability: 95,
      reason: language === 'hi' ? 'वर्तमान मिट्टी और मौसम के लिए उत्तम' : 'Perfect for current soil and weather'
    },
    {
      name: 'Chickpea',
      nameHi: 'चना',
      season: 'rabi',
      suitability: 88,
      reason: language === 'hi' ? 'कम पानी की आवश्यकता' : 'Low water requirement'
    },
    {
      name: 'Barley',
      nameHi: 'जौ',
      season: 'rabi',
      suitability: 82,
      reason: language === 'hi' ? 'अच्छी बाजार मांग' : 'Good market demand'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />
      
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? 'फसल प्रबंधन' : 'Crop Management'}
          </h1>
          <p className="text-gray-600">
            {language === 'hi' 
              ? 'अपनी फसलों की निगरानी करें और नई फसल के सुझाव प्राप्त करें' 
              : 'Monitor your crops and get new crop recommendations'
            }
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{cropStats.total}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'कुल फसलें' : 'Total Crops'}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{cropStats.growing}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'बढ़ रही हैं' : 'Growing'}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{cropStats.harvested}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'कटाई हो गई' : 'Harvested'}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{cropStats.totalArea}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'कुल एकड़' : 'Total Acres'}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Filters and Actions */}
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <CardTitle className="flex items-center gap-2">
                    <Sprout className="h-5 w-5 text-green-600" />
                    {language === 'hi' ? 'मेरी फसलें' : 'My Crops'}
                  </CardTitle>
                  <div className="flex gap-2">
                    <Select value={selectedSeason} onValueChange={setSelectedSeason}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder={language === 'hi' ? 'सीजन' : 'Season'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">{language === 'hi' ? 'सभी सीजन' : 'All Seasons'}</SelectItem>
                        {Object.entries(CROP_SEASONS).map(([key, season]) => (
                          <SelectItem key={key} value={key}>
                            {language === 'hi' ? season.labelHi : season.labelEn}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder={language === 'hi' ? 'स्थिति' : 'Status'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">{language === 'hi' ? 'सभी स्थिति' : 'All Status'}</SelectItem>
                        <SelectItem value="growing">{language === 'hi' ? 'बढ़ रही' : 'Growing'}</SelectItem>
                        <SelectItem value="harvested">{language === 'hi' ? 'कटाई हो गई' : 'Harvested'}</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button className="bg-green-600 hover:bg-green-700">
                      <Plus className="h-4 w-4 mr-2" />
                      {language === 'hi' ? 'नई फसल' : 'Add Crop'}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {filteredCrops.map((crop) => (
                    <CropCard key={crop.id} crop={crop} language={language} />
                  ))}
                </div>
                {filteredCrops.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    {language === 'hi' 
                      ? 'चुने गए फिल्टर के लिए कोई फसल नहीं मिली' 
                      : 'No crops found for selected filters'
                    }
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Crop Calendar */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-blue-600" />
                  {language === 'hi' ? 'फसल कैलेंडर' : 'Crop Calendar'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(CROP_SEASONS).map(([key, season]) => (
                    <div key={key} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium">
                          {language === 'hi' ? season.labelHi : season.labelEn}
                        </h3>
                        <Badge variant="outline">{season.months}</Badge>
                      </div>
                      <div className="text-sm text-gray-600">
                        {key === 'kharif' && (language === 'hi' 
                          ? 'चावल, मक्का, कपास, गन्ना के लिए आदर्श'
                          : 'Ideal for rice, corn, cotton, sugarcane'
                        )}
                        {key === 'rabi' && (language === 'hi' 
                          ? 'गेहूं, जौ, चना, सरसों के लिए आदर्श'
                          : 'Ideal for wheat, barley, chickpea, mustard'
                        )}
                        {key === 'zaid' && (language === 'hi' 
                          ? 'तरबूज, खरबूजा, चारा फसलों के लिए आदर्श'
                          : 'Ideal for watermelon, muskmelon, fodder crops'
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recommended Crops */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  {language === 'hi' ? 'सुझाई गई फसलें' : 'Recommended Crops'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recommendedCrops.map((crop, index) => (
                  <div key={index} className="p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">
                        {language === 'hi' ? crop.nameHi : crop.name}
                      </h4>
                      <Badge className="bg-green-100 text-green-800">
                        {crop.suitability}%
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{crop.reason}</p>
                    <Button size="sm" variant="outline" className="w-full">
                      {language === 'hi' ? 'विवरण देखें' : 'View Details'}
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'त्वरित कार्य' : 'Quick Actions'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'सिंचाई शेड्यूल करें' : 'Schedule Irrigation'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Sprout className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'फसल स्वास्थ्य जांचें' : 'Check Crop Health'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'उत्पादन रिपोर्ट' : 'Yield Report'}
                </Button>
              </CardContent>
            </Card>

            {/* Seasonal Tips */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'मौसमी सुझाव' : 'Seasonal Tips'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-800 mb-1">
                      {language === 'hi' ? 'रबी सीजन' : 'Rabi Season'}
                    </h4>
                    <p className="text-sm text-blue-600">
                      {language === 'hi' 
                        ? 'गेहूं और चना की बुआई का समय है। मिट्टी की नमी बनाए रखें।'
                        : 'Time for wheat and chickpea sowing. Maintain soil moisture.'
                      }
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
