import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import Navbar from '@/components/Navbar';
import { mockSoilData } from '@/lib/mockData';
import { SOIL_PARAMETERS } from '@/lib/constants';
import { Beaker, TrendingUp, AlertCircle, CheckCircle, Calendar } from 'lucide-react';

export default function SoilHealth() {
  const [language, setLanguage] = useState('en');
  const [soilData, setSoilData] = useState(mockSoilData);

  const getParameterStatus = (value: number, parameter: keyof typeof SOIL_PARAMETERS) => {
    const { optimal } = SOIL_PARAMETERS[parameter];
    if (value >= optimal[0] && value <= optimal[1]) {
      return { status: 'optimal', color: 'text-green-600', bgColor: 'bg-green-100' };
    } else if (value < optimal[0] * 0.8 || value > optimal[1] * 1.2) {
      return { status: 'poor', color: 'text-red-600', bgColor: 'bg-red-100' };
    } else {
      return { status: 'fair', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    }
  };

  const soilParameters = [
    { key: 'pH', label: language === 'hi' ? 'pH स्तर' : 'pH Level', value: soilData.pH, unit: '' },
    { key: 'nitrogen', label: language === 'hi' ? 'नाइट्रोजन' : 'Nitrogen', value: soilData.nitrogen, unit: 'mg/kg' },
    { key: 'phosphorus', label: language === 'hi' ? 'फास्फोरस' : 'Phosphorus', value: soilData.phosphorus, unit: 'mg/kg' },
    { key: 'potassium', label: language === 'hi' ? 'पोटेशियम' : 'Potassium', value: soilData.potassium, unit: 'mg/kg' },
    { key: 'moisture', label: language === 'hi' ? 'नमी' : 'Moisture', value: soilData.moisture, unit: '%' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />
      
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? 'मिट्टी स्वास्थ्य प्रबंधन' : 'Soil Health Management'}
          </h1>
          <p className="text-gray-600">
            {language === 'hi' 
              ? 'अपनी मिट्टी के स्वास्थ्य की निगरानी करें और सुधार के सुझाव प्राप्त करें' 
              : 'Monitor your soil health and get improvement recommendations'
            }
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Soil Parameters */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-blue-600" />
                  {language === 'hi' ? 'मिट्टी परीक्षण परिणाम' : 'Soil Test Results'}
                  <Badge variant="secondary">
                    {language === 'hi' ? 'अंतिम परीक्षण:' : 'Last Test:'} {soilData.lastTested}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  {soilParameters.map((param) => {
                    const status = getParameterStatus(param.value, param.key as keyof typeof SOIL_PARAMETERS);
                    const optimal = SOIL_PARAMETERS[param.key as keyof typeof SOIL_PARAMETERS].optimal;
                    const progress = (param.value / SOIL_PARAMETERS[param.key as keyof typeof SOIL_PARAMETERS].max) * 100;
                    
                    return (
                      <div key={param.key} className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-medium">{param.label}</Label>
                          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${status.bgColor} ${status.color}`}>
                            {status.status === 'optimal' ? (
                              <CheckCircle className="h-3 w-3" />
                            ) : (
                              <AlertCircle className="h-3 w-3" />
                            )}
                            {status.status}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{param.value}{param.unit}</span>
                            <span className="text-gray-500">
                              {language === 'hi' ? 'आदर्श:' : 'Optimal:'} {optimal[0]}-{optimal[1]}{param.unit}
                            </span>
                          </div>
                          <Progress value={progress} className="h-2" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  {language === 'hi' ? 'सुधार सुझाव' : 'Improvement Recommendations'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {soilData.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-green-800">{rec}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Add New Test Data */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-purple-600" />
                  {language === 'hi' ? 'नया परीक्षण डेटा जोड़ें' : 'Add New Test Data'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ph">{language === 'hi' ? 'pH स्तर' : 'pH Level'}</Label>
                    <Input id="ph" type="number" placeholder="6.8" step="0.1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="nitrogen">{language === 'hi' ? 'नाइट्रोजन (mg/kg)' : 'Nitrogen (mg/kg)'}</Label>
                    <Input id="nitrogen" type="number" placeholder="35" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phosphorus">{language === 'hi' ? 'फास्फोरस (mg/kg)' : 'Phosphorus (mg/kg)'}</Label>
                    <Input id="phosphorus" type="number" placeholder="22" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="potassium">{language === 'hi' ? 'पोटेशियम (mg/kg)' : 'Potassium (mg/kg)'}</Label>
                    <Input id="potassium" type="number" placeholder="18" />
                  </div>
                </div>
                <Button className="mt-4 bg-green-600 hover:bg-green-700">
                  {language === 'hi' ? 'डेटा सेव करें' : 'Save Data'}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Overall Health Score */}
            <Card>
              <CardHeader>
                <CardTitle className="text-center">
                  {language === 'hi' ? 'समग्र स्वास्थ्य स्कोर' : 'Overall Health Score'}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-4xl font-bold text-green-600 mb-2">85/100</div>
                <div className="text-sm text-gray-600 mb-4">
                  {language === 'hi' ? 'अच्छा स्वास्थ्य' : 'Good Health'}
                </div>
                <Progress value={85} className="h-3" />
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'त्वरित सुझाव' : 'Quick Tips'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-800 mb-1">
                    {language === 'hi' ? 'जैविक खाद' : 'Organic Compost'}
                  </h4>
                  <p className="text-sm text-blue-600">
                    {language === 'hi' 
                      ? 'मिट्टी की उर्वरता बढ़ाने के लिए जैविक खाद का उपयोग करें'
                      : 'Use organic compost to improve soil fertility'
                    }
                  </p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-800 mb-1">
                    {language === 'hi' ? 'फसल चक्र' : 'Crop Rotation'}
                  </h4>
                  <p className="text-sm text-green-600">
                    {language === 'hi' 
                      ? 'मिट्टी के पोषक तत्वों को संतुलित रखने के लिए फसल चक्र अपनाएं'
                      : 'Practice crop rotation to balance soil nutrients'
                    }
                  </p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <h4 className="font-medium text-purple-800 mb-1">
                    {language === 'hi' ? 'नियमित परीक्षण' : 'Regular Testing'}
                  </h4>
                  <p className="text-sm text-purple-600">
                    {language === 'hi' 
                      ? 'हर 6 महीने में मिट्टी का परीक्षण कराएं'
                      : 'Test your soil every 6 months for best results'
                    }
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
