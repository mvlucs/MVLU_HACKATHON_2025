import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import Navbar from '@/components/Navbar';
import WeatherWidget from '@/components/WeatherWidget';
import CropCard from '@/components/CropCard';
import { mockDashboardStats, mockCropsData } from '@/lib/mockData';
import { Sprout, Droplets, TrendingUp, AlertTriangle, MapPin, Calendar, IndianRupee, Activity } from 'lucide-react';

export default function Dashboard() {
  const [language, setLanguage] = useState('en');
  const stats = mockDashboardStats;
  const activeCrops = mockCropsData.filter(crop => crop.status === 'Growing');

  const quickStats = [
    {
      icon: <MapPin className="h-5 w-5 text-green-600" />,
      label: language === 'hi' ? 'कुल क्षेत्र' : 'Total Area',
      value: `${stats.totalArea} ${language === 'hi' ? 'एकड़' : 'acres'}`,
      color: 'text-green-600'
    },
    {
      icon: <Sprout className="h-5 w-5 text-blue-600" />,
      label: language === 'hi' ? 'सक्रिय फसलें' : 'Active Crops',
      value: stats.activeCrops,
      color: 'text-blue-600'
    },
    {
      icon: <Activity className="h-5 w-5 text-purple-600" />,
      label: language === 'hi' ? 'मिट्टी स्वास्थ्य' : 'Soil Health',
      value: stats.soilHealth,
      color: 'text-purple-600'
    },
    {
      icon: <IndianRupee className="h-5 w-5 text-orange-600" />,
      label: language === 'hi' ? 'मासिक आय' : 'Monthly Income',
      value: `₹${stats.monthlyIncome.toLocaleString()}`,
      color: 'text-orange-600'
    }
  ];

  const upcomingTasks = [
    { task: language === 'hi' ? 'गेहूं की सिंचाई' : 'Wheat Irrigation', due: language === 'hi' ? '2 दिन में' : 'In 2 days', priority: 'high' },
    { task: language === 'hi' ? 'टमाटर में खाद' : 'Tomato Fertilization', due: language === 'hi' ? '5 दिन में' : 'In 5 days', priority: 'medium' },
    { task: language === 'hi' ? 'मिट्टी परीक्षण' : 'Soil Testing', due: language === 'hi' ? '1 सप्ताह में' : 'In 1 week', priority: 'low' },
    { task: language === 'hi' ? 'कीट निरीक्षण' : 'Pest Inspection', due: language === 'hi' ? '3 दिन में' : 'In 3 days', priority: 'medium' }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />
      
      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? 'किसान डैशबोर्ड' : 'Farmer Dashboard'}
          </h1>
          <p className="text-gray-600">
            {language === 'hi' 
              ? 'आपकी खेती की गतिविधियों का सिंहावलोकन' 
              : 'Overview of your farming activities'
            }
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {quickStats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  {stat.icon}
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className={`text-lg font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Weather Widget */}
            <WeatherWidget language={language} />

            {/* Active Crops */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sprout className="h-5 w-5 text-green-600" />
                  {language === 'hi' ? 'सक्रिय फसलें' : 'Active Crops'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {activeCrops.map((crop) => (
                    <CropCard key={crop.id} crop={crop} language={language} />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Resource Usage */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-blue-600" />
                  {language === 'hi' ? 'संसाधन उपयोग' : 'Resource Usage'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-600">
                      {language === 'hi' ? 'पानी का उपयोग' : 'Water Usage'}
                    </span>
                    <span className="text-sm font-medium">{stats.waterUsage}%</span>
                  </div>
                  <Progress value={stats.waterUsage} className="h-2" />
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">{language === 'hi' ? 'इस महीने' : 'This Month'}</p>
                    <p className="font-bold text-blue-600">2,400L</p>
                  </div>
                  <div>
                    <p className="text-gray-600">{language === 'hi' ? 'लक्ष्य' : 'Target'}</p>
                    <p className="font-bold text-green-600">3,200L</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  {language === 'hi' ? 'अलर्ट' : 'Alerts'}
                  <Badge variant="secondary">{stats.recentAlerts}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                  <p className="text-sm font-medium text-orange-800">
                    {language === 'hi' 
                      ? 'भारी बारिश की चेतावनी' 
                      : 'Heavy Rainfall Warning'
                    }
                  </p>
                  <p className="text-xs text-orange-600 mt-1">
                    {language === 'hi' ? '2 दिन में' : 'In 2 days'}
                  </p>
                </div>
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm font-medium text-yellow-800">
                    {language === 'hi' 
                      ? 'सिंचाई का समय' 
                      : 'Irrigation Due'
                    }
                  </p>
                  <p className="text-xs text-yellow-600 mt-1">
                    {language === 'hi' ? 'गेहूं के लिए' : 'For wheat crop'}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Tasks */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-purple-600" />
                  {language === 'hi' ? 'आगामी कार्य' : 'Upcoming Tasks'}
                  <Badge variant="secondary">{stats.upcomingTasks}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {upcomingTasks.map((task, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium">{task.task}</p>
                      <p className="text-xs text-gray-500">{task.due}</p>
                    </div>
                    <Badge className={getPriorityColor(task.priority)}>
                      {task.priority}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  {language === 'hi' ? 'त्वरित कार्य' : 'Quick Actions'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <button className="w-full p-3 text-left bg-green-50 hover:bg-green-100 rounded-lg transition-colors">
                  <p className="text-sm font-medium text-green-800">
                    {language === 'hi' ? 'नई फसल जोड़ें' : 'Add New Crop'}
                  </p>
                </button>
                <button className="w-full p-3 text-left bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">
                  <p className="text-sm font-medium text-blue-800">
                    {language === 'hi' ? 'मिट्टी डेटा अपडेट करें' : 'Update Soil Data'}
                  </p>
                </button>
                <button className="w-full p-3 text-left bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors">
                  <p className="text-sm font-medium text-purple-800">
                    {language === 'hi' ? 'विशेषज्ञ से सलाह लें' : 'Consult Expert'}
                  </p>
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
