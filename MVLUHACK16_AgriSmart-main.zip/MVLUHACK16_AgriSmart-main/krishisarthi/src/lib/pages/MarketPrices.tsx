import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Navbar from '@/components/Navbar';
import { mockMarketPrices } from '@/lib/mockData';
import { TrendingUp, TrendingDown, Search, MapPin, IndianRupee, BarChart3, RefreshCw } from 'lucide-react';

export default function MarketPrices() {
  const [language, setLanguage] = useState('en');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('all');

  const filteredPrices = mockMarketPrices.filter(item => {
    const nameMatch = item.crop.toLowerCase().includes(searchTerm.toLowerCase()) ||
                     item.cropHi.includes(searchTerm);
    return nameMatch;
  });

  const priceStats = {
    totalCrops: mockMarketPrices.length,
    priceIncreases: mockMarketPrices.filter(item => item.trend === 'up').length,
    priceDecreases: mockMarketPrices.filter(item => item.trend === 'down').length,
    avgPrice: Math.round(mockMarketPrices.reduce((sum, item) => sum + item.price, 0) / mockMarketPrices.length)
  };

  const marketNews = [
    {
      title: language === 'hi' ? 'गेहूं की कीमतों में वृद्धि' : 'Wheat Prices Rise',
      description: language === 'hi' 
        ? 'सरकारी खरीद के कारण गेहूं की कीमतों में 2.5% की वृद्धि हुई है।'
        : 'Wheat prices increased by 2.5% due to government procurement.',
      time: '2 hours ago',
      impact: 'positive'
    },
    {
      title: language === 'hi' ? 'टमाटर की अधिक आपूर्ति' : 'Tomato Oversupply',
      description: language === 'hi' 
        ? 'बंपर फसल के कारण टमाटर की कीमतों में गिरावट की संभावना है।'
        : 'Bumper harvest may lead to decline in tomato prices.',
      time: '5 hours ago',
      impact: 'negative'
    },
    {
      title: language === 'hi' ? 'कपास निर्यात बढ़ा' : 'Cotton Export Increases',
      description: language === 'hi' 
        ? 'अंतर्राष्ट्रीय मांग में वृद्धि से कपास की कीमतें स्थिर हैं।'
        : 'Stable cotton prices due to increased international demand.',
      time: '1 day ago',
      impact: 'neutral'
    }
  ];

  const locations = [
    { value: 'all', label: language === 'hi' ? 'सभी बाजार' : 'All Markets' },
    { value: 'delhi', label: language === 'hi' ? 'दिल्ली' : 'Delhi' },
    { value: 'mumbai', label: language === 'hi' ? 'मुंबई' : 'Mumbai' },
    { value: 'kolkata', label: language === 'hi' ? 'कोलकाता' : 'Kolkata' },
    { value: 'chennai', label: language === 'hi' ? 'चेन्नई' : 'Chennai' }
  ];

  const getTrendIcon = (trend: string) => {
    return trend === 'up' ? (
      <TrendingUp className="h-4 w-4 text-green-600" />
    ) : (
      <TrendingDown className="h-4 w-4 text-red-600" />
    );
  };

  const getTrendColor = (trend: string) => {
    return trend === 'up' ? 'text-green-600' : 'text-red-600';
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'positive': return 'border-l-green-500 bg-green-50';
      case 'negative': return 'border-l-red-500 bg-red-50';
      default: return 'border-l-blue-500 bg-blue-50';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />
      
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? 'बाजार मूल्य और व्यापार' : 'Market Prices & Trading'}
          </h1>
          <p className="text-gray-600">
            {language === 'hi' 
              ? 'वास्तविक समय के बाजार मूल्य और व्यापार की जानकारी प्राप्त करें' 
              : 'Get real-time market prices and trading information'
            }
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{priceStats.totalCrops}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'कुल फसलें' : 'Total Crops'}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{priceStats.priceIncreases}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'कीमत बढ़ी' : 'Price Increased'}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-600">{priceStats.priceDecreases}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'कीमत घटी' : 'Price Decreased'}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">₹{priceStats.avgPrice}</div>
              <div className="text-sm text-gray-600">
                {language === 'hi' ? 'औसत मूल्य' : 'Average Price'}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search and Filters */}
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <CardTitle className="flex items-center gap-2">
                    <IndianRupee className="h-5 w-5 text-green-600" />
                    {language === 'hi' ? 'आज के मंडी भाव' : "Today's Market Rates"}
                  </CardTitle>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder={language === 'hi' ? 'फसल खोजें...' : 'Search crops...'}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-48"
                      />
                    </div>
                    <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.map((location) => (
                          <SelectItem key={location.value} value={location.value}>
                            {location.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="icon">
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {filteredPrices.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                          <span className="text-xl">🌾</span>
                        </div>
                        <div>
                          <h3 className="font-medium">
                            {language === 'hi' ? item.cropHi : item.crop}
                          </h3>
                          <p className="text-sm text-gray-500">{item.unit}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-lg font-bold">₹{item.price.toLocaleString()}</span>
                          {getTrendIcon(item.trend)}
                        </div>
                        <div className={`text-sm ${getTrendColor(item.trend)}`}>
                          {item.change > 0 ? '+' : ''}₹{item.change}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Price Chart Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-purple-600" />
                  {language === 'hi' ? 'मूल्य रुझान चार्ट' : 'Price Trend Chart'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                  <div className="text-center text-gray-500">
                    <BarChart3 className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>{language === 'hi' ? 'मूल्य चार्ट जल्द ही उपलब्ध होगा' : 'Price chart coming soon'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Market News */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-orange-600" />
                  {language === 'hi' ? 'बाजार समाचार' : 'Market News'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {marketNews.map((news, index) => (
                  <div key={index} className={`p-3 border-l-4 rounded-r-lg ${getImpactColor(news.impact)}`}>
                    <h4 className="font-medium mb-1">{news.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{news.description}</p>
                    <span className="text-xs text-gray-500">{news.time}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Top Gainers/Losers */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'टॉप गेनर्स/लूजर्स' : 'Top Gainers/Losers'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-green-600 mb-2 flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      {language === 'hi' ? 'सबसे ज्यादा बढ़े' : 'Top Gainers'}
                    </h4>
                    {mockMarketPrices
                      .filter(item => item.trend === 'up')
                      .sort((a, b) => b.change - a.change)
                      .slice(0, 3)
                      .map((item, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span>{language === 'hi' ? item.cropHi : item.crop}</span>
                          <span className="text-green-600">+₹{item.change}</span>
                        </div>
                      ))}
                  </div>
                  <div>
                    <h4 className="font-medium text-red-600 mb-2 flex items-center gap-1">
                      <TrendingDown className="h-4 w-4" />
                      {language === 'hi' ? 'सबसे ज्यादा घटे' : 'Top Losers'}
                    </h4>
                    {mockMarketPrices
                      .filter(item => item.trend === 'down')
                      .sort((a, b) => a.change - b.change)
                      .slice(0, 3)
                      .map((item, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span>{language === 'hi' ? item.cropHi : item.crop}</span>
                          <span className="text-red-600">₹{item.change}</span>
                        </div>
                      ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'त्वरित कार्य' : 'Quick Actions'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <IndianRupee className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'मूल्य अलर्ट सेट करें' : 'Set Price Alerts'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'मूल्य रिपोर्ट डाउनलोड करें' : 'Download Price Report'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <MapPin className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'नजदीकी मंडी खोजें' : 'Find Nearby Markets'}
                </Button>
              </CardContent>
            </Card>

            {/* Government Schemes */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'सरकारी योजनाएं' : 'Government Schemes'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-800 mb-1">
                      {language === 'hi' ? 'PM-KISAN' : 'PM-KISAN'}
                    </h4>
                    <p className="text-sm text-blue-600">
                      {language === 'hi' 
                        ? '₹6000 प्रति वर्ष सीधे किसानों के खाते में'
                        : '₹6000 per year directly to farmers accounts'
                      }
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-medium text-green-800 mb-1">
                      {language === 'hi' ? 'MSP योजना' : 'MSP Scheme'}
                    </h4>
                    <p className="text-sm text-green-600">
                      {language === 'hi' 
                        ? 'न्यूनतम समर्थन मूल्य की गारंटी'
                        : 'Guaranteed minimum support price'
                      }
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
