import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Navbar from '@/components/Navbar';
import WeatherWidget from '@/components/WeatherWidget';
import { mockWeatherData } from '@/lib/mockData';
import { Cloud, Droplets, Wind, Sun, AlertTriangle, Info, Bell, Thermometer } from 'lucide-react';

export default function WeatherAlerts() {
  const [language, setLanguage] = useState('en');

  const irrigationRecommendations = [
    {
      crop: 'Wheat',
      cropHi: 'गेहूं',
      recommendation: language === 'hi' ? 'अगले 2 दिन में सिंचाई करें' : 'Irrigate in next 2 days',
      reason: language === 'hi' ? 'मिट्टी की नमी कम हो रही है' : 'Soil moisture decreasing',
      priority: 'high'
    },
    {
      crop: 'Tomato',
      cropHi: 'टमाटर',
      recommendation: language === 'hi' ? 'सिंचाई रोकें - बारिश आने वाली है' : 'Hold irrigation - rain expected',
      reason: language === 'hi' ? '2 दिन में भारी बारिश' : 'Heavy rain in 2 days',
      priority: 'medium'
    }
  ];

  const weatherAlerts = [
    {
      type: 'warning',
      title: language === 'hi' ? 'भारी बारिश चेतावनी' : 'Heavy Rainfall Warning',
      message: language === 'hi' 
        ? '48 घंटों में 50-75mm बारिश की संभावना। जल निकासी की व्यवस्था करें।'
        : 'Expected 50-75mm rainfall in next 48 hours. Prepare drainage systems.',
      time: '2 hours ago',
      severity: 'high'
    },
    {
      type: 'info',
      title: language === 'hi' ? 'अनुकूल तापमान' : 'Favorable Temperature',
      message: language === 'hi' 
        ? 'गेहूं के अंकुरण के लिए आदर्श तापमान (20-25°C) अगले सप्ताह तक बना रहेगा।'
        : 'Ideal temperature for wheat germination (20-25°C) will continue next week.',
      time: '6 hours ago',
      severity: 'low'
    },
    {
      type: 'caution',
      title: language === 'hi' ? 'हवा की गति बढ़ी' : 'Increased Wind Speed',
      message: language === 'hi' 
        ? 'तेज हवा (25-30 km/h) से फसलों को नुकसान हो सकता है। सहारा दें।'
        : 'Strong winds (25-30 km/h) may damage crops. Provide support.',
      time: '12 hours ago',
      severity: 'medium'
    }
  ];

  const weeklyOutlook = [
    { day: 'Mon', temp: { min: 15, max: 28 }, condition: 'Sunny', rainfall: 0, wind: 8 },
    { day: 'Tue', temp: { min: 16, max: 30 }, condition: 'Partly Cloudy', rainfall: 0, wind: 12 },
    { day: 'Wed', temp: { min: 18, max: 26 }, condition: 'Heavy Rain', rainfall: 65, wind: 22 },
    { day: 'Thu', temp: { min: 17, max: 25 }, condition: 'Light Rain', rainfall: 15, wind: 18 },
    { day: 'Fri', temp: { min: 16, max: 27 }, condition: 'Cloudy', rainfall: 5, wind: 14 },
    { day: 'Sat', temp: { min: 15, max: 29 }, condition: 'Sunny', rainfall: 0, wind: 10 },
    { day: 'Sun', temp: { min: 17, max: 31 }, condition: 'Sunny', rainfall: 0, wind: 8 }
  ];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'caution': return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      default: return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getAlertColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'border-red-200 bg-red-50';
      case 'medium': return 'border-orange-200 bg-orange-50';
      default: return 'border-blue-200 bg-blue-50';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-orange-100 text-orange-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />
      
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? 'मौसम अलर्ट और सिंचाई गाइड' : 'Weather Alerts & Irrigation Guide'}
          </h1>
          <p className="text-gray-600">
            {language === 'hi' 
              ? 'मौसम की जानकारी और सिंचाई के सुझाव प्राप्त करें' 
              : 'Get weather information and irrigation recommendations'
            }
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Current Weather */}
            <WeatherWidget language={language} />

            {/* Weather Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-red-600" />
                  {language === 'hi' ? 'मौसम अलर्ट' : 'Weather Alerts'}
                  <Badge variant="secondary">{weatherAlerts.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {weatherAlerts.map((alert, index) => (
                  <div key={index} className={`p-4 border rounded-lg ${getAlertColor(alert.severity)}`}>
                    <div className="flex items-start gap-3">
                      {getAlertIcon(alert.type)}
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">{alert.title}</h3>
                          <span className="text-xs text-gray-500">{alert.time}</span>
                        </div>
                        <p className="text-sm text-gray-700 mb-2">{alert.message}</p>
                        <Badge className={getPriorityColor(alert.severity)}>
                          {alert.severity} priority
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Weekly Outlook */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-purple-600" />
                  {language === 'hi' ? '7 दिन का पूर्वानुमान' : '7-Day Outlook'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-2">
                  {weeklyOutlook.map((day, index) => (
                    <div key={index} className="text-center p-3 bg-gray-50 rounded-lg">
                      <p className="font-medium text-sm mb-2">{day.day}</p>
                      <div className="space-y-1">
                        <div className="text-xs">
                          <span className="font-bold">{day.temp.max}°</span>
                          <span className="text-gray-500">/{day.temp.min}°</span>
                        </div>
                        <div className="text-xs text-gray-600">{day.condition}</div>
                        {day.rainfall > 0 && (
                          <div className="flex items-center justify-center gap-1 text-xs text-blue-600">
                            <Droplets className="h-3 w-3" />
                            {day.rainfall}mm
                          </div>
                        )}
                        <div className="flex items-center justify-center gap-1 text-xs text-gray-500">
                          <Wind className="h-3 w-3" />
                          {day.wind}km/h
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Irrigation Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-blue-600" />
                  {language === 'hi' ? 'सिंचाई सुझाव' : 'Irrigation Recommendations'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {irrigationRecommendations.map((rec, index) => (
                  <div key={index} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">
                        {language === 'hi' ? rec.cropHi : rec.crop}
                      </h4>
                      <Badge className={getPriorityColor(rec.priority)}>
                        {rec.priority}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-700 mb-2">{rec.recommendation}</p>
                    <p className="text-xs text-gray-500">{rec.reason}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Weather Statistics */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'मौसम आंकड़े' : 'Weather Statistics'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Thermometer className="h-4 w-4 text-red-500" />
                    <span className="text-sm">{language === 'hi' ? 'औसत तापमान' : 'Avg Temperature'}</span>
                  </div>
                  <span className="font-bold">26°C</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Droplets className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">{language === 'hi' ? 'कुल बारिश' : 'Total Rainfall'}</span>
                  </div>
                  <span className="font-bold">85mm</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Wind className="h-4 w-4 text-gray-500" />
                    <span className="text-sm">{language === 'hi' ? 'औसत हवा' : 'Avg Wind'}</span>
                  </div>
                  <span className="font-bold">12 km/h</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sun className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">{language === 'hi' ? 'धूप के घंटे' : 'Sunshine Hours'}</span>
                  </div>
                  <span className="font-bold">8.5h</span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>{language === 'hi' ? 'त्वरित कार्य' : 'Quick Actions'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Bell className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'अलर्ट सेट करें' : 'Set Alerts'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Droplets className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'सिंचाई प्लान करें' : 'Plan Irrigation'}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Cloud className="h-4 w-4 mr-2" />
                  {language === 'hi' ? 'मौसम रिपोर्ट' : 'Weather Report'}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
