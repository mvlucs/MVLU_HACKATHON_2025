export const mockWeatherData = {
  current: {
    temperature: 28,
    humidity: 65,
    rainfall: 12,
    windSpeed: 8,
    condition: "Partly Cloudy"
  },
  forecast: [
    { day: "Today", temp: 28, condition: "Partly Cloudy", rainfall: 0 },
    { day: "Tomorrow", temp: 30, condition: "Sunny", rainfall: 0 },
    { day: "Day 3", temp: 26, condition: "Light Rain", rainfall: 5 },
    { day: "Day 4", temp: 25, condition: "Heavy Rain", rainfall: 15 },
    { day: "Day 5", temp: 27, condition: "Cloudy", rainfall: 2 }
  ],
  alerts: [
    { type: "warning", message: "Heavy rainfall expected in 2 days. Prepare drainage systems." },
    { type: "info", message: "Optimal temperature for wheat germination this week." }
  ]
};

export const mockSoilData = {
  pH: 6.8,
  nitrogen: 35,
  phosphorus: 22,
  potassium: 18,
  moisture: 45,
  organicMatter: 3.2,
  lastTested: "2024-09-10",
  recommendations: [
    "Soil pH is optimal for most crops",
    "Consider adding phosphorus-rich fertilizer",
    "Maintain current irrigation schedule"
  ]
};

export const mockCropsData = [
  {
    id: 1,
    name: "Wheat",
    nameHi: "गेहूं",
    season: "rabi",
    plantedDate: "2024-11-15",
    expectedHarvest: "2024-04-10",
    area: 2.5,
    status: "Growing",
    health: "Good",
    stage: "Tillering",
    daysToHarvest: 45,
    expectedYield: 3200,
    image: "🌾"
  },
  {
    id: 2,
    name: "Rice",
    nameHi: "चावल",
    season: "kharif",
    plantedDate: "2024-07-01",
    expectedHarvest: "2024-10-15",
    area: 1.8,
    status: "Harvested",
    health: "Excellent",
    stage: "Harvested",
    daysToHarvest: 0,
    expectedYield: 2800,
    image: "🌾"
  },
  {
    id: 3,
    name: "Tomato",
    nameHi: "टमाटर",
    season: "rabi",
    plantedDate: "2024-12-01",
    expectedHarvest: "2024-03-15",
    area: 0.5,
    status: "Growing",
    health: "Fair",
    stage: "Flowering",
    daysToHarvest: 75,
    expectedYield: 1500,
    image: "🍅"
  }
];

export const mockMarketPrices = [
  { crop: "Wheat", cropHi: "गेहूं", price: 2150, unit: "per quintal", change: +50, trend: "up" },
  { crop: "Rice", cropHi: "चावल", price: 3200, unit: "per quintal", change: -25, trend: "down" },
  { crop: "Tomato", cropHi: "टमाटर", price: 4500, unit: "per quintal", change: +200, trend: "up" },
  { crop: "Onion", cropHi: "प्याज", price: 3800, unit: "per quintal", change: -150, trend: "down" },
  { crop: "Potato", cropHi: "आलू", price: 1800, unit: "per quintal", change: +75, trend: "up" },
  { crop: "Cotton", cropHi: "कपास", price: 5600, unit: "per quintal", change: +100, trend: "up" }
];

export const mockKnowledgeBase = [
  {
    id: 1,
    category: "Soil Care",
    categoryHi: "मिट्टी की देखभाल",
    title: "Improving Soil Fertility Naturally",
    titleHi: "प्राकृतिक रूप से मिट्टी की उर्वरता बढ़ाना",
    content: "Use organic compost, crop rotation, and cover crops to enhance soil health...",
    tags: ["organic", "fertility", "compost"]
  },
  {
    id: 2,
    category: "Pest Control",
    categoryHi: "कीट नियंत्रण",
    title: "Integrated Pest Management",
    titleHi: "एकीकृत कीट प्रबंधन",
    content: "Combine biological, cultural, and chemical methods for effective pest control...",
    tags: ["IPM", "biological", "sustainable"]
  },
  {
    id: 3,
    category: "Water Management",
    categoryHi: "जल प्रबंधन",
    title: "Efficient Irrigation Techniques",
    titleHi: "कुशल सिंचाई तकनीकें",
    content: "Drip irrigation and mulching can reduce water usage by up to 50%...",
    tags: ["irrigation", "water-saving", "drip"]
  },
  {
    id: 4,
    category: "Crop Selection",
    categoryHi: "फसल चयन",
    title: "Climate-Resilient Crops",
    titleHi: "जलवायु प्रतिरोधी फसलें",
    content: "Choose drought-tolerant varieties for sustainable farming...",
    tags: ["climate", "drought", "resilient"]
  }
];

export const mockDashboardStats = {
  totalArea: 4.8,
  activeCrops: 2,
  soilHealth: "Good",
  weatherStatus: "Favorable",
  monthlyIncome: 45000,
  waterUsage: 75,
  recentAlerts: 2,
  upcomingTasks: 5
};
