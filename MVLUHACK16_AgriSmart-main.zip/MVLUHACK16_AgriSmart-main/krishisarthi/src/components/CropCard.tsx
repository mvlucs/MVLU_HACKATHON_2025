import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Calendar, MapPin, TrendingUp } from 'lucide-react';

interface Crop {
  id: number;
  name: string;
  nameHi: string;
  season: string;
  plantedDate: string;
  expectedHarvest: string;
  area: number;
  status: string;
  health: string;
  stage: string;
  daysToHarvest: number;
  expectedYield: number;
  image: string;
}

interface CropCardProps {
  crop: Crop;
  language: string;
}

export default function CropCard({ crop, language }: CropCardProps) {
  const getHealthColor = (health: string) => {
    switch (health.toLowerCase()) {
      case 'excellent': return 'bg-green-500';
      case 'good': return 'bg-green-400';
      case 'fair': return 'bg-yellow-400';
      case 'poor': return 'bg-red-400';
      default: return 'bg-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'growing': return 'bg-green-100 text-green-800';
      case 'harvested': return 'bg-blue-100 text-blue-800';
      case 'planted': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const progressPercentage = crop.daysToHarvest > 0 
    ? Math.max(0, 100 - (crop.daysToHarvest / 120) * 100) 
    : 100;

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <span className="text-2xl">{crop.image}</span>
            <span>{language === 'hi' ? crop.nameHi : crop.name}</span>
          </CardTitle>
          <Badge className={getStatusColor(crop.status)}>
            {crop.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Health Status */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">
            {language === 'hi' ? 'स्वास्थ्य' : 'Health'}
          </span>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${getHealthColor(crop.health)}`} />
            <span className="text-sm font-medium">{crop.health}</span>
          </div>
        </div>

        {/* Growth Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">
              {language === 'hi' ? 'विकास प्रगति' : 'Growth Progress'}
            </span>
            <span className="text-sm font-medium">{crop.stage}</span>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>

        {/* Key Information */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-gray-400" />
            <div>
              <p className="text-gray-600">{language === 'hi' ? 'क्षेत्र' : 'Area'}</p>
              <p className="font-medium">{crop.area} {language === 'hi' ? 'एकड़' : 'acres'}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-gray-400" />
            <div>
              <p className="text-gray-600">
                {crop.daysToHarvest > 0 
                  ? (language === 'hi' ? 'कटाई में दिन' : 'Days to Harvest')
                  : (language === 'hi' ? 'कटाई हो गई' : 'Harvested')
                }
              </p>
              <p className="font-medium">
                {crop.daysToHarvest > 0 ? `${crop.daysToHarvest} days` : '✓'}
              </p>
            </div>
          </div>
        </div>

        {/* Expected Yield */}
        <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
          <TrendingUp className="h-4 w-4 text-green-600" />
          <div>
            <p className="text-sm text-green-700">
              {language === 'hi' ? 'अपेक्षित उत्पादन' : 'Expected Yield'}
            </p>
            <p className="font-medium text-green-800">
              {crop.expectedYield} kg
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
