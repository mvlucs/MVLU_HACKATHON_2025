import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Cloud, Droplets, Wind, Thermometer, AlertTriangle, Info } from 'lucide-react';
import { mockWeatherData } from '@/lib/mockData';

interface WeatherWidgetProps {
  language: string;
}

export default function WeatherWidget({ language }: WeatherWidgetProps) {
  const { current, forecast, alerts } = mockWeatherData;

  return (
    <div className="space-y-4">
      {/* Current Weather */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5 text-blue-500" />
            {language === 'hi' ? 'वर्तमान मौसम' : 'Current Weather'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              <Thermometer className="h-4 w-4 text-red-500" />
              <div>
                <p className="text-2xl font-bold">{current.temperature}°C</p>
                <p className="text-sm text-gray-500">{language === 'hi' ? 'तापमान' : 'Temperature'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Droplets className="h-4 w-4 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{current.humidity}%</p>
                <p className="text-sm text-gray-500">{language === 'hi' ? 'नमी' : 'Humidity'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Cloud className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-2xl font-bold">{current.rainfall}mm</p>
                <p className="text-sm text-gray-500">{language === 'hi' ? 'बारिश' : 'Rainfall'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Wind className="h-4 w-4 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{current.windSpeed} km/h</p>
                <p className="text-sm text-gray-500">{language === 'hi' ? 'हवा' : 'Wind'}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weather Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((alert, index) => (
            <Alert key={index} className={alert.type === 'warning' ? 'border-orange-200 bg-orange-50' : 'border-blue-200 bg-blue-50'}>
              {alert.type === 'warning' ? (
                <AlertTriangle className="h-4 w-4 text-orange-500" />
              ) : (
                <Info className="h-4 w-4 text-blue-500" />
              )}
              <AlertDescription>{alert.message}</AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      {/* 5-Day Forecast */}
      <Card>
        <CardHeader>
          <CardTitle>{language === 'hi' ? '5 दिन का पूर्वानुमान' : '5-Day Forecast'}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 gap-2">
            {forecast.map((day, index) => (
              <div key={index} className="text-center p-2 rounded-lg bg-gray-50">
                <p className="text-sm font-medium">{day.day}</p>
                <p className="text-lg font-bold">{day.temp}°C</p>
                <p className="text-xs text-gray-500">{day.condition}</p>
                {day.rainfall > 0 && (
                  <Badge variant="secondary" className="text-xs mt-1">
                    {day.rainfall}mm
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
