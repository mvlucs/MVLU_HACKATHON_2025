"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Navbar from "@/components/Navbar"
import { mockMarketPrices } from "@/lib/mockData"
import { TrendingUp, TrendingDown, IndianRupee, BarChart3 } from "lucide-react"

export default function MarketPrices() {
  const [language, setLanguage] = useState("en")

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{language === "hi" ? "बाजार मूल्य" : "Market Prices"}</h1>
          <p className="text-gray-600">
            {language === "hi" ? "वर्तमान बाजार मूल्य और रुझान देखें" : "View current market prices and trends"}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-green-600" />
              {language === "hi" ? "आज के मूल्य" : "Today's Prices"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {mockMarketPrices.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div>
                    <h3 className="font-medium">{language === "hi" ? item.cropHi : item.crop}</h3>
                    <p className="text-sm text-gray-500">{item.unit}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2">
                      <IndianRupee className="h-4 w-4" />
                      <span className="text-lg font-bold">₹{item.price}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {item.trend === "up" ? (
                        <TrendingUp className="h-4 w-4 text-green-500" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-500" />
                      )}
                      <Badge variant={item.trend === "up" ? "default" : "destructive"}>
                        {item.change > 0 ? "+" : ""}
                        {item.change}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
