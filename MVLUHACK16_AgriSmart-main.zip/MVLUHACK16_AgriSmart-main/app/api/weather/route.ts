import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const lat = searchParams.get("lat")
    const lon = searchParams.get("lon")
    const location = searchParams.get("location") || "Delhi"

    const supabase = await createClient()

    let weatherData = null
    let currentWeather = null

    // Try to fetch from OpenWeatherMap API if coordinates are provided
    if (lat && lon) {
      try {
        const openWeatherApiKey = process.env.OPENWEATHER_API_KEY
        if (openWeatherApiKey) {
          const [currentResponse, forecastResponse] = await Promise.all([
            fetch(
              `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${openWeatherApiKey}&units=metric`,
            ),
            fetch(
              `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${openWeatherApiKey}&units=metric`,
            ),
          ])

          if (currentResponse.ok && forecastResponse.ok) {
            const currentData = await currentResponse.json()
            const forecastData = await forecastResponse.json()

            // Transform OpenWeatherMap data to our format
            currentWeather = {
              temperature: Math.round(currentData.main.temp),
              condition: currentData.weather[0].main.toLowerCase(),
              humidity: currentData.main.humidity,
              windSpeed: Math.round(currentData.wind.speed * 3.6), // Convert m/s to km/h
              rainfall: currentData.rain?.["1h"] || 0,
              visibility: currentData.visibility ? Math.round(currentData.visibility / 1000) : 10,
              pressure: currentData.main.pressure,
              uvIndex: 5, // OpenWeatherMap UV requires separate API call
              location: currentData.name,
            }

            // Transform forecast data (5-day forecast with 3-hour intervals)
            const dailyForecast = []
            const processedDays = new Set()

            for (const item of forecastData.list.slice(0, 40)) {
              // 5 days * 8 intervals
              const date = new Date(item.dt * 1000)
              const dayKey = date.toDateString()

              if (!processedDays.has(dayKey) && dailyForecast.length < 5) {
                processedDays.add(dayKey)
                const dayName =
                  dailyForecast.length === 0
                    ? "Today"
                    : dailyForecast.length === 1
                      ? "Tomorrow"
                      : date.toLocaleDateString("en", { weekday: "short" })

                dailyForecast.push({
                  day: dayName,
                  temp: Math.round(item.main.temp),
                  condition: item.weather[0].main.toLowerCase(),
                  rain: Math.round((item.pop || 0) * 100), // Probability of precipitation
                })
              }
            }

            weatherData = {
              ...currentWeather,
              forecast: dailyForecast,
            }

            try {
              await supabase.from("weather_data").insert({
                location: currentWeather.location,
                temperature: currentWeather.temperature,
                humidity: currentWeather.humidity,
                rainfall: currentWeather.rainfall,
                wind_speed: currentWeather.windSpeed,
                weather_condition: currentWeather.condition,
                date: new Date().toISOString().split("T")[0],
              })
            } catch (dbError) {
              console.log("Failed to cache weather data:", dbError)
            }
          }
        }
      } catch (apiError) {
        console.error("OpenWeatherMap API error:", apiError)
      }
    }

    // Fallback to database if API failed or no coordinates provided
    if (!weatherData) {
      const { data: dbWeatherData, error } = await supabase
        .from("weather_data")
        .select("*")
        .eq("location", location)
        .order("date", { ascending: false })
        .limit(7)

      if (!error && dbWeatherData && dbWeatherData.length > 0) {
        const current = dbWeatherData[0]
        weatherData = {
          temperature: current.temperature,
          condition: current.weather_condition,
          humidity: current.humidity,
          windSpeed: current.wind_speed,
          rainfall: current.rainfall,
          visibility: 8,
          pressure: 1013,
          uvIndex: 5,
          location: current.location,
          forecast: dbWeatherData.slice(0, 5).map((item, index) => ({
            day:
              index === 0
                ? "Today"
                : index === 1
                  ? "Tomorrow"
                  : new Date(item.date).toLocaleDateString("en", { weekday: "short" }),
            temp: item.temperature,
            condition: item.weather_condition,
            rain: Math.round(Math.random() * 100),
          })),
        }
      }
    }

    // Final fallback to mock data
    if (!weatherData) {
      const mockData = generateMockWeatherData(location)
      const current = mockData[0]
      weatherData = {
        temperature: Math.round(current.temperature),
        condition: current.weather_condition.toLowerCase().replace(" ", "-"),
        humidity: Math.round(current.humidity),
        windSpeed: Math.round(current.wind_speed),
        rainfall: Math.round(current.rainfall * 10) / 10,
        visibility: 8,
        pressure: 1013,
        uvIndex: 5,
        location: current.location,
        forecast: mockData.slice(0, 5).map((item, index) => ({
          day:
            index === 0
              ? "Today"
              : index === 1
                ? "Tomorrow"
                : new Date(item.date).toLocaleDateString("en", { weekday: "short" }),
          temp: Math.round(item.temperature),
          condition: item.weather_condition.toLowerCase().replace(" ", "-"),
          rain: Math.round(Math.random() * 100),
        })),
      }
    }

    return NextResponse.json({
      success: true,
      weather: weatherData,
    })
  } catch (error) {
    console.error("Weather API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

function generateMockWeatherData(location: string) {
  const baseTemp = location === "Mumbai" ? 32 : location === "Delhi" ? 28 : 26
  const baseHumidity = location === "Mumbai" ? 78 : location === "Delhi" ? 65 : 60

  return Array.from({ length: 7 }, (_, i) => ({
    id: `mock-${i}`,
    location,
    temperature: baseTemp + Math.random() * 6 - 3,
    humidity: baseHumidity + Math.random() * 20 - 10,
    rainfall: Math.random() * 5,
    wind_speed: 8 + Math.random() * 15,
    weather_condition: ["Clear", "Partly Cloudy", "Cloudy", "Light Rain"][Math.floor(Math.random() * 4)],
    date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    created_at: new Date().toISOString(),
  }))
}
