import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const crop = searchParams.get("crop")
    const state = searchParams.get("state")
    const limit = Number.parseInt(searchParams.get("limit") || "50")

    const supabase = await createClient()

    let query = supabase
      .from("market_prices")
      .select(`
        *,
        crop_varieties (
          variety_name,
          quality_grade
        )
      `)
      .order("date", { ascending: false })

    if (crop) {
      query = query.ilike("crop_name", `%${crop}%`)
    }

    if (state) {
      query = query.ilike("state", `%${state}%`)
    }

    const { data: pricesData, error } = await query.limit(limit)

    if (error) {
      console.error("Database error:", error)

      const mockPrices = generateEnhancedMockPrices(crop, state)
      return NextResponse.json({
        success: true,
        prices: mockPrices,
        source: "mock",
        filters: { crop, state, limit },
      })
    }

    const processedPrices =
      pricesData?.map((price) => {
        const trend = Math.random() > 0.5 ? "up" : "down"
        const changePercent = (Math.random() * 10 - 5).toFixed(1)

        return {
          ...price,
          trend,
          change_percent: Number.parseFloat(changePercent),
          change_amount: Math.round(price.price_per_quintal * (Number.parseFloat(changePercent) / 100)),
        }
      }) || []

    // Group prices by crop for better organization
    const groupedPrices = processedPrices.reduce((acc: any, price: any) => {
      const cropName = price.crop_name
      if (!acc[cropName]) {
        acc[cropName] = []
      }
      acc[cropName].push(price)
      return acc
    }, {})

    const marketStats = {
      total_crops: Object.keys(groupedPrices).length,
      price_increases: processedPrices.filter((p) => p.trend === "up").length,
      price_decreases: processedPrices.filter((p) => p.trend === "down").length,
      avg_price:
        processedPrices.length > 0
          ? Math.round(processedPrices.reduce((sum, p) => sum + p.price_per_quintal, 0) / processedPrices.length)
          : 0,
      highest_price: processedPrices.length > 0 ? Math.max(...processedPrices.map((p) => p.price_per_quintal)) : 0,
      lowest_price: processedPrices.length > 0 ? Math.min(...processedPrices.map((p) => p.price_per_quintal)) : 0,
    }

    return NextResponse.json({
      success: true,
      prices: processedPrices,
      grouped_prices: groupedPrices,
      market_stats: marketStats,
      filters: { crop, state, limit },
      source: "database",
    })
  } catch (error) {
    console.error("Market Prices API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

function generateEnhancedMockPrices(crop?: string | null, state?: string | null) {
  const crops = [
    { name: "Wheat", nameHi: "गेहूं", basePrice: 2150 },
    { name: "Rice", nameHi: "चावल", basePrice: 3200 },
    { name: "Tomato", nameHi: "टमाटर", basePrice: 4500 },
    { name: "Onion", nameHi: "प्याज", basePrice: 3800 },
    { name: "Potato", nameHi: "आलू", basePrice: 1800 },
    { name: "Cotton", nameHi: "कपास", basePrice: 5600 },
    { name: "Sugarcane", nameHi: "गन्ना", basePrice: 350 },
    { name: "Maize", nameHi: "मक्का", basePrice: 1950 },
  ]

  const states = ["Maharashtra", "Punjab", "Uttar Pradesh", "Gujarat", "Rajasthan"]
  const markets = ["APMC", "Mandi", "Wholesale Market", "Retail Market"]

  return crops
    .filter((c) => !crop || c.name.toLowerCase().includes(crop.toLowerCase()))
    .map((cropItem) => {
      const trend = Math.random() > 0.5 ? "up" : "down"
      const changePercent = (Math.random() * 8 - 4).toFixed(1)
      const currentPrice = cropItem.basePrice + (Math.random() * 400 - 200)

      return {
        id: `mock-${cropItem.name.toLowerCase()}`,
        crop_name: cropItem.name,
        crop_name_hi: cropItem.nameHi,
        price_per_quintal: Math.round(currentPrice),
        unit: "quintal",
        market_name: markets[Math.floor(Math.random() * markets.length)],
        state: state || states[Math.floor(Math.random() * states.length)],
        district: "Sample District",
        date: new Date().toISOString().split("T")[0],
        trend,
        change_percent: Number.parseFloat(changePercent),
        change_amount: Math.round(currentPrice * (Number.parseFloat(changePercent) / 100)),
        quality_grade: ["A", "B", "C"][Math.floor(Math.random() * 3)],
      }
    })
}
