"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import Navbar from "@/components/Navbar"
import { mockKnowledgeBase } from "@/lib/mockData"
import { BookOpen, Search, Tag } from "lucide-react"

export default function KnowledgeBase() {
  const [language, setLanguage] = useState("en")
  const [searchTerm, setSearchTerm] = useState("")

  const filteredArticles = mockKnowledgeBase.filter(
    (article) =>
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.titleHi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{language === "hi" ? "ज्ञान केंद्र" : "Knowledge Base"}</h1>
          <p className="text-gray-600">
            {language === "hi"
              ? "कृषि संबंधी जानकारी और सुझाव प्राप्त करें"
              : "Get agricultural information and recommendations"}
          </p>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder={language === "hi" ? "खोजें..." : "Search..."}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Articles */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => (
            <Card key={article.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <Badge variant="secondary">{language === "hi" ? article.categoryHi : article.category}</Badge>
                  <BookOpen className="h-4 w-4 text-gray-400" />
                </div>
                <CardTitle className="text-lg">{language === "hi" ? article.titleHi : article.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">{article.content}</p>
                <div className="flex flex-wrap gap-1">
                  {article.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredArticles.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">{language === "hi" ? "कोई लेख नहीं मिला" : "No articles found"}</p>
          </div>
        )}
      </main>
    </div>
  )
}
