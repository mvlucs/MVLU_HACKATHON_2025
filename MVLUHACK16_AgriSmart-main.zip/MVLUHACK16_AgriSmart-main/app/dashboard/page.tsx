"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Navbar from "@/components/Navbar"
import CropCard from "@/components/CropCard"
import WeatherWidget from "@/components/WeatherWidget"
import {
  Sprout,
  TrendingUp,
  IndianRupee,
  AlertTriangle,
  Calendar,
  Plus,
  Settings,
  BarChart3,
  Loader2,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import { useI18n } from "@/lib/i18n/context"

interface MarketPrice {
  crop_name: string
  price_per_kg: number
  market_name: string
  date: string
}

interface WeatherData {
  location: string
  temperature: number
  humidity: number
  weather_condition: string
}

export default function Dashboard() {
  const { language, t } = useI18n()
  const [marketPrices, setMarketPrices] = useState<MarketPrice[]>([])
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // Fetch market prices
      const pricesResponse = await fetch("/api/prices")
      const pricesData = await pricesResponse.json()
      if (pricesData.success) {
        setMarketPrices(pricesData.prices.slice(0, 4)) // Get top 4 prices
      }

      // Fetch weather data
      const weatherResponse = await fetch("/api/weather?location=Delhi")
      const weatherData = await weatherResponse.json()
      if (weatherData.success) {
        setWeatherData(weatherData.current)
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error)
      toast({
        title: t("common.error"),
        description: language === "hi" ? "डेटा लोड करने मे��� त्रुटि" : "Error loading dashboard data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const quickStats = [
    {
      title: t("dashboard.totalArea"),
      value: "12.5",
      unit: t("units.acres"),
      icon: <Sprout className="h-5 w-5 text-green-600" />,
      trend: "+2.3%",
    },
    {
      title: t("dashboard.activeCrops"),
      value: "4",
      unit: language === "hi" ? "फसलें" : "crops",
      icon: <TrendingUp className="h-5 w-5 text-blue-600" />,
      trend: "+1",
    },
    {
      title: t("dashboard.soilHealth"),
      value: "85",
      unit: t("units.percent"),
      icon: <BarChart3 className="h-5 w-5 text-purple-600" />,
      trend: "+5%",
    },
    {
      title: t("dashboard.monthlyIncome"),
      value: "₹45,000",
      unit: "",
      icon: <IndianRupee className="h-5 w-5 text-orange-600" />,
      trend: "+12%",
    },
  ]

  const activeCrops = [
    {
      id: 1,
      name: language === "hi" ? "गेहूं" : "Wheat",
      area: 5.2,
      health: 92,
      daysToHarvest: 45,
      expectedYield: 2800,
      image: "/golden-wheat-field.png",
    },
    {
      id: 2,
      name: language === "hi" ? "मक्का" : "Corn",
      area: 3.8,
      health: 88,
      daysToHarvest: 62,
      expectedYield: 3200,
      image: "/endless-cornfield.png",
    },
    {
      id: 3,
      name: language === "hi" ? "टमाटर" : "Tomato",
      area: 2.1,
      health: 95,
      daysToHarvest: 28,
      expectedYield: 1500,
      image: "/vibrant-tomato-plants.png",
    },
    {
      id: 4,
      name: language === "hi" ? "प्याज" : "Onion",
      area: 1.4,
      health: 78,
      daysToHarvest: 85,
      expectedYield: 900,
      image: "/onion-field.jpg",
    },
  ]

  const alerts = [
    {
      type: "warning",
      titleEn: "Irrigation Required",
      titleHi: "सिंचाई आवश्यक",
      descEn: "Wheat field moisture level is below optimal",
      descHi: "गेहूं के खेत में नमी का स्तर इष्टतम से कम है",
    },
    {
      type: "info",
      titleEn: "Weather Alert",
      titleHi: "मौसम चेतावनी",
      descEn: weatherData
        ? `${weatherData.weather_condition} - ${weatherData.temperature}°C`
        : "Light rain expected in next 2 days",
      descHi: weatherData
        ? `${weatherData.weather_condition} - ${weatherData.temperature}°C`
        : "अगले 2 दिनों में हल्की बारिश की संभावना",
    },
  ]

  const upcomingTasks = [
    {
      titleEn: "Apply fertilizer to corn field",
      titleHi: "मक्का के खेत में उर्वरक डालें",
      date: "2024-01-15",
      priority: "high",
    },
    {
      titleEn: "Harvest tomatoes",
      titleHi: "टमाटर की कटाई करें",
      date: "2024-01-18",
      priority: "medium",
    },
    {
      titleEn: "Soil testing for onion field",
      titleHi: "प्याज के खेत के लिए मिट्टी परीक्षण",
      date: "2024-01-20",
      priority: "low",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{t("dashboard.title")}</h1>
            <p className="text-gray-600 mt-1">{t("dashboard.subtitle")}</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              {t("dashboard.settings")}
            </Button>
            <Button size="sm" className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              {t("dashboard.addCrop")}
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {quickStats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <div className="flex items-baseline space-x-1">
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <p className="text-sm text-gray-500">{stat.unit}</p>
                    </div>
                    <p className="text-xs text-green-600 font-medium">{stat.trend}</p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-full">{stat.icon}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Active Crops */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Sprout className="h-5 w-5 text-green-600" />
                  <span>{language === "hi" ? "सक्रिय फसलें" : "Active Crops"}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activeCrops.map((crop) => (
                    <CropCard key={crop.id} crop={crop} language={language} />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Market Prices */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <IndianRupee className="h-5 w-5 text-green-600" />
                    <span>{language === "hi" ? "आज के बाजार भाव" : "Today's Market Prices"}</span>
                  </div>
                  <Link href="/market-prices">
                    <Button variant="outline" size="sm">
                      {language === "hi" ? "सभी देखें" : "View All"}
                    </Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {marketPrices.map((price, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900">{price.crop_name}</h4>
                          <p className="text-sm text-gray-600">{price.market_name}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-green-600">₹{price.price_per_kg}/kg</p>
                          <p className="text-xs text-gray-500">{new Date(price.date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  <span>{language === "hi" ? "अलर्ट" : "Alerts"}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {alerts.map((alert, index) => (
                    <div key={index} className="flex items-start space-x-3 p-4 bg-orange-50 rounded-lg">
                      <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-gray-900">
                          {language === "hi" ? alert.titleHi : alert.titleEn}
                        </h4>
                        <p className="text-sm text-gray-600">{language === "hi" ? alert.descHi : alert.descEn}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Weather Widget */}
            <WeatherWidget language={language} />

            {/* Upcoming Tasks */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-blue-600" />
                  <span>{language === "hi" ? "आगामी कार्य" : "Upcoming Tasks"}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingTasks.map((task, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          task.priority === "high"
                            ? "bg-red-500"
                            : task.priority === "medium"
                              ? "bg-yellow-500"
                              : "bg-green-500"
                        }`}
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          {language === "hi" ? task.titleHi : task.titleEn}
                        </p>
                        <p className="text-xs text-gray-500">{task.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>{language === "hi" ? "त्वरित कार्य" : "Quick Actions"}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Link href="/soil-health">
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      {language === "hi" ? "मिट्टी परीक्षण" : "Soil Analysis"}
                    </Button>
                  </Link>
                  <Link href="/disease-detection">
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      {language === "hi" ? "रोग पहचान" : "Disease Detection"}
                    </Button>
                  </Link>
                  <Link href="/market-prices">
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      {language === "hi" ? "बाजार मूल्य देखें" : "View Market Prices"}
                    </Button>
                  </Link>
                  <Link href="/encyclopedia">
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Sprout className="h-4 w-4 mr-2" />
                      {language === "hi" ? "फसल विश्वकोश" : "Crop Encyclopedia"}
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
