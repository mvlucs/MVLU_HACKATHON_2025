"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Navbar from "@/components/Navbar"
import { Sprout, Users, BarChart3, Shield, Globe, Smartphone } from "lucide-react"
import { useI18n } from "@/lib/i18n/context"

export default function Index() {
  const { language, t } = useI18n()

  const features = [
    {
      icon: <Sprout className="h-8 w-8 text-green-600" />,
      titleEn: "Smart Crop Management",
      titleHi: "स्मार्ट फसल प्रबंधन",
      descEn: "AI-powered crop selection and monitoring for optimal yield",
      descHi: "अधिकतम उत्पादन के लिए AI-संचालित फसल चयन और निगरानी",
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-blue-600" />,
      titleEn: "Soil Health Analytics",
      titleHi: "मिट्टी स्वास्थ्य विश्लेषण",
      descEn: "Real-time soil monitoring and personalized recommendations",
      descHi: "वास्तविक समय मिट्टी निगरानी और व्यक्तिगत सुझाव",
    },
    {
      icon: <Shield className="h-8 w-8 text-red-600" />,
      titleEn: "Disease Detection",
      titleHi: "रोग पहचान",
      descEn: "Early pest and disease detection using AI image analysis",
      descHi: "AI छवि विश्लेषण का उपयोग करके प्रारंभिक कीट और रोग की पहचान",
    },
    {
      icon: <Globe className="h-8 w-8 text-purple-600" />,
      titleEn: "Weather Intelligence",
      titleHi: "मौसम बुद्धिमत्ता",
      descEn: "Accurate weather forecasts and irrigation guidance",
      descHi: "सटीक मौसम पूर्वानुमान और सिंचाई मार्गदर्शन",
    },
    {
      icon: <Users className="h-8 w-8 text-orange-600" />,
      titleEn: "Market Connect",
      titleHi: "बाजार कनेक्ट",
      descEn: "Real-time market prices and direct buyer connections",
      descHi: "वास्तविक समय बाजार मूल्य और प्रत्यक्ष खरीदार कनेक्शन",
    },
    {
      icon: <Smartphone className="h-8 w-8 text-teal-600" />,
      titleEn: "Mobile Optimized",
      titleHi: "मोबाइल अनुकूलित",
      descEn: "Works seamlessly on all devices with offline capabilities",
      descHi: "सभी उपकरणों पर ऑफलाइन क्षमताओं के साथ निर्बाध रूप से काम करता है",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="mb-8">
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-4">
              {language === "hi" ? "एग्रीस्मार्ट" : "AgriSmart"}
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8">
              {language === "hi" ? "व्यापक फसल और मिट्टी प्रबंधन प्रणाली" : "Comprehensive Crop & Soil Management System"}
            </p>
            <p className="text-lg text-gray-500 max-w-3xl mx-auto mb-8">
              {language === "hi"
                ? "AI-संचालित कृषि प्लेटफॉर्म जो स्मार्ट फसल चयन, मिट्टी स्वास्थ्य प्रबंधन, रोग की पहचान, मौसम बुद्धिमत्ता और बाजार कनेक्शन प्रदान करता है।"
                : "AI-powered agricultural platform for smart crop selection, soil health management, disease detection, weather intelligence, and market connections."}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dashboard">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-3">
                {t("dashboard.title")}
              </Button>
            </Link>
            <Link href="/encyclopedia">
              <Button
                size="lg"
                variant="outline"
                className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-3 bg-transparent"
              >
                {t("nav.knowledge")}
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 p-3 bg-gray-50 rounded-full w-fit">{feature.icon}</div>
                <CardTitle className="text-xl">{language === "hi" ? feature.titleHi : feature.titleEn}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">{language === "hi" ? feature.descHi : feature.descEn}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats Section */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">
            {language === "hi" ? "प्रभाव आंकड़े" : "Impact Statistics"}
          </h2>
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-green-600 mb-2">10,000+</div>
              <div className="text-gray-600">{language === "hi" ? "सक्रिय किसान" : "Active Farmers"}</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-600 mb-2">25%</div>
              <div className="text-gray-600">{language === "hi" ? "उत्पादन वृद्धि" : "Yield Increase"}</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-600 mb-2">30%</div>
              <div className="text-gray-600">{language === "hi" ? "पानी की बचत" : "Water Savings"}</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-600 mb-2">50+</div>
              <div className="text-gray-600">{language === "hi" ? "समर्थित फसलें" : "Supported Crops"}</div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-2xl p-8">
          <h2 className="text-3xl font-bold mb-4">{language === "hi" ? "आज ही शुरू करें" : "Get Started Today"}</h2>
          <p className="text-xl mb-6">
            {language === "hi"
              ? "अपनी कृषि यात्रा को बदलें और स्मार्ट खेती की शुरुआत करें।"
              : "Transform your farming journey and start smart agriculture today."}
          </p>
          <Link href="/dashboard">
            <Button size="lg" variant="secondary" className="bg-white text-green-600 hover:bg-gray-100">
              {language === "hi" ? "अभी शुरू करें" : "Start Now"}
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
