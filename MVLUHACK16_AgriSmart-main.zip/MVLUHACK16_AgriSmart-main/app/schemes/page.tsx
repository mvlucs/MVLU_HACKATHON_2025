"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import Navbar from "@/components/Navbar"
import {
  Search,
  Filter,
  FileText,
  Users,
  IndianRupee,
  Phone,
  MapPin,
  ExternalLink,
  CheckCircle,
  AlertCircle,
  Info,
} from "lucide-react"

interface Scheme {
  id: string
  scheme_name: string
  description: string
  eligibility: string
  benefits: string
  application_process: string
  contact_info: string
  state: string
  category: string
  is_active: boolean
  created_at: string
  application_deadline?: string
  budget_allocation?: string
  beneficiaries_count?: number
  website_url?: string
}

export default function SchemesPage() {
  const [language, setLanguage] = useState("en")
  const [schemes, setSchemes] = useState<Scheme[]>([])
  const [filteredSchemes, setFilteredSchemes] = useState<Scheme[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedState, setSelectedState] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedScheme, setSelectedScheme] = useState<Scheme | null>(null)

  const mockSchemes: Scheme[] = [
    {
      id: "1",
      scheme_name: "PM-KISAN",
      description:
        language === "hi"
          ? "प्रधानमंत्री किसान सम्मान निधि योजना के तहत छोटे और सीमांत किसानों को प्रति वर्ष ₹6000 की आर्थिक सहायता प्रदान की जाती है।"
          : "Pradhan Mantri Kisan Samman Nidhi provides ₹6000 per year to small and marginal farmers as income support.",
      eligibility:
        language === "hi"
          ? "2 हेक्टेयर तक की कृषि भूमि वाले किसान परिवार पात्र हैं।"
          : "Farmer families with cultivable land up to 2 hectares are eligible.",
      benefits:
        language === "hi"
          ? "₹6000 प्रति वर्ष तीन समान किस्तों में सीधे बैंक खाते में।"
          : "₹6000 per year in three equal installments directly to bank account.",
      application_process:
        language === "hi"
          ? "ऑनलाइन पंजीकरण pmkisan.gov.in पर या नजदीकी CSC केंद्र पर।"
          : "Online registration at pmkisan.gov.in or visit nearest CSC center.",
      contact_info: "Helpline: 155261, Email: pmkisan-ict@gov.in",
      state: "All India",
      category: "Income Support",
      is_active: true,
      created_at: "2024-01-01",
      application_deadline: "Open throughout the year",
      budget_allocation: "₹75,000 crores",
      beneficiaries_count: 11000000,
      website_url: "https://pmkisan.gov.in",
    },
    {
      id: "2",
      scheme_name: "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
      description:
        language === "hi"
          ? "प्राकृतिक आपदाओं से होने वाले नुकसान के लिए किसानों को बीमा कवर प्रदान करती है।"
          : "Provides insurance coverage to farmers against crop losses due to natural calamities.",
      eligibility:
        language === "hi"
          ? "सभी किसान जो अधिसूचित फसलों की खेती करते हैं।"
          : "All farmers growing notified crops are eligible.",
      benefits:
        language === "hi"
          ? "खरीफ फसलों के लिए 2%, रबी के लिए 1.5% प्रीमियम दर।"
          : "Premium rates: 2% for Kharif, 1.5% for Rabi crops.",
      application_process:
        language === "hi"
          ? "बैंक, CSC केंद्र या बीमा कंपनी के माध्यम से आवेदन करें।"
          : "Apply through banks, CSC centers, or insurance companies.",
      contact_info: "Helpline: 14447, Email: support.pmfby@gov.in",
      state: "All India",
      category: "Insurance",
      is_active: true,
      created_at: "2024-01-01",
      budget_allocation: "₹15,695 crores",
      beneficiaries_count: 5500000,
      website_url: "https://pmfby.gov.in",
    },
    {
      id: "3",
      scheme_name: "Kisan Credit Card (KCC)",
      description:
        language === "hi"
          ? "किसानों को कृषि और संबद्ध गतिविधियों के लिए समय पर और पर्याप्त ऋण प्रदान करता है।"
          : "Provides timely and adequate credit to farmers for agriculture and allied activities.",
      eligibility: language === "hi" ? "सभी किसान जिनके पास कृषि भूमि है।" : "All farmers who own agricultural land.",
      benefits: language === "hi" ? "4% ब्याज दर पर ₹3 लाख तक का ऋण।" : "Loan up to ₹3 lakhs at 4% interest rate.",
      application_process: language === "hi" ? "नजदीकी बैंक शाखा में आवेदन करें।" : "Apply at nearest bank branch.",
      contact_info: "Contact your nearest bank branch",
      state: "All India",
      category: "Credit",
      is_active: true,
      created_at: "2024-01-01",
      beneficiaries_count: 7000000,
      website_url: "https://kcc.gov.in",
    },
    {
      id: "4",
      scheme_name: "Soil Health Card Scheme",
      description:
        language === "hi"
          ? "किसानों को मिट्टी की स्वास्थ्य स्थिति की जानकारी प्रदान करता है।"
          : "Provides information about soil health status to farmers.",
      eligibility: language === "hi" ? "सभी किसान जो कृषि करते हैं।" : "All farmers engaged in agriculture.",
      benefits:
        language === "hi" ? "मुफ्त मिट्टी परीक्षण और उर्वरक सिफारिशें।" : "Free soil testing and fertilizer recommendations.",
      application_process:
        language === "hi" ? "कृषि विभाग के कार्यालय में संपर्क करें।" : "Contact agriculture department office.",
      contact_info: "Contact local agriculture department",
      state: "All India",
      category: "Soil Health",
      is_active: true,
      created_at: "2024-01-01",
      beneficiaries_count: 22000000,
      website_url: "https://soilhealth.dac.gov.in",
    },
    {
      id: "5",
      scheme_name: "PM Kisan Maan Dhan Yojana",
      description:
        language === "hi" ? "छोटे और सीमांत किसानों के लिए पेंशन योजना।" : "Pension scheme for small and marginal farmers.",
      eligibility:
        language === "hi" ? "18-40 वर्ष की आयु के छोटे और सीमांत किसान।" : "Small and marginal farmers aged 18-40 years.",
      benefits: language === "hi" ? "60 वर्ष की आयु के बाद ₹3000 मासिक पेंशन।" : "₹3000 monthly pension after age 60.",
      application_process: language === "hi" ? "CSC केंद्र या ऑनलाइन पंजीकरण।" : "Register at CSC center or online.",
      contact_info: "Helpline: 14434",
      state: "All India",
      category: "Pension",
      is_active: true,
      created_at: "2024-01-01",
      beneficiaries_count: 2000000,
      website_url: "https://maandhan.in",
    },
    {
      id: "6",
      scheme_name: "National Agriculture Market (e-NAM)",
      description:
        language === "hi"
          ? "किसानों को बेहतर मूल्य दिलाने के लिए ऑनलाइन व्यापार मंच।"
          : "Online trading platform to provide better prices to farmers.",
      eligibility: language === "hi" ? "सभी किसान और व्यापारी।" : "All farmers and traders.",
      benefits:
        language === "hi"
          ? "पारदर्शी मूल्य खोज और बेहतर बाजार पहुंच।"
          : "Transparent price discovery and better market access.",
      application_process: language === "hi" ? "enam.gov.in पर ऑनलाइन पंजीकरण।" : "Online registration at enam.gov.in.",
      contact_info: "Email: enam-dmi@gov.in",
      state: "All India",
      category: "Marketing",
      is_active: true,
      created_at: "2024-01-01",
      beneficiaries_count: 1700000,
      website_url: "https://enam.gov.in",
    },
  ]

  useEffect(() => {
    fetchSchemes()
  }, [])

  useEffect(() => {
    filterSchemes()
  }, [schemes, searchTerm, selectedState, selectedCategory])

  const fetchSchemes = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/schemes")
      const data = await response.json()

      if (data.success && data.schemes.length > 0) {
        setSchemes(data.schemes)
      } else {
        // Use mock data as fallback
        setSchemes(mockSchemes)
      }
    } catch (error) {
      console.error("Failed to fetch schemes:", error)
      setSchemes(mockSchemes)
    } finally {
      setLoading(false)
    }
  }

  const filterSchemes = () => {
    let filtered = schemes

    if (searchTerm) {
      filtered = filtered.filter(
        (scheme) =>
          scheme.scheme_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          scheme.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          scheme.category.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (selectedState !== "all") {
      filtered = filtered.filter((scheme) => scheme.state === selectedState || scheme.state === "All India")
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((scheme) => scheme.category === selectedCategory)
    }

    setFilteredSchemes(filtered)
  }

  const states = [
    { value: "all", label: language === "hi" ? "सभी राज्य" : "All States" },
    { value: "All India", label: language === "hi" ? "अखिल भारतीय" : "All India" },
    { value: "Maharashtra", label: language === "hi" ? "महाराष्ट्र" : "Maharashtra" },
    { value: "Punjab", label: language === "hi" ? "पंजाब" : "Punjab" },
    { value: "Uttar Pradesh", label: language === "hi" ? "उत्तर प्रदेश" : "Uttar Pradesh" },
    { value: "Gujarat", label: language === "hi" ? "गुजरात" : "Gujarat" },
    { value: "Rajasthan", label: language === "hi" ? "राजस्थान" : "Rajasthan" },
  ]

  const categories = [
    { value: "all", label: language === "hi" ? "सभी श्रेणियां" : "All Categories" },
    { value: "Income Support", label: language === "hi" ? "आय सहायता" : "Income Support" },
    { value: "Insurance", label: language === "hi" ? "बीमा" : "Insurance" },
    { value: "Credit", label: language === "hi" ? "ऋण" : "Credit" },
    { value: "Soil Health", label: language === "hi" ? "मिट्टी स्वास्थ्य" : "Soil Health" },
    { value: "Pension", label: language === "hi" ? "पेंशन" : "Pension" },
    { value: "Marketing", label: language === "hi" ? "विपणन" : "Marketing" },
  ]

  const getCategoryColor = (category: string) => {
    const colors = {
      "Income Support": "bg-green-100 text-green-800",
      Insurance: "bg-blue-100 text-blue-800",
      Credit: "bg-purple-100 text-purple-800",
      "Soil Health": "bg-orange-100 text-orange-800",
      Pension: "bg-pink-100 text-pink-800",
      Marketing: "bg-teal-100 text-teal-800",
    }
    return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar language={language} onLanguageChange={setLanguage} />

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === "hi" ? "सरकारी योजनाएं" : "Government Schemes"}
          </h1>
          <p className="text-gray-600">
            {language === "hi"
              ? "किसानों के लिए सरकारी योजनाओं और सब्सिडी की जानकारी प्राप्त करें"
              : "Explore government schemes and subsidies available for farmers"}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{filteredSchemes.length}</div>
              <div className="text-sm text-gray-600">{language === "hi" ? "कुल योजनाएं" : "Total Schemes"}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {filteredSchemes.filter((s) => s.state === "All India").length}
              </div>
              <div className="text-sm text-gray-600">{language === "hi" ? "राष्ट्रीय योजनाएं" : "National Schemes"}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {new Set(filteredSchemes.map((s) => s.category)).size}
              </div>
              <div className="text-sm text-gray-600">{language === "hi" ? "श्रेणियां" : "Categories"}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">
                {Math.round(filteredSchemes.reduce((sum, s) => sum + (s.beneficiaries_count || 0), 0) / 1000000)}M
              </div>
              <div className="text-sm text-gray-600">{language === "hi" ? "लाभार्थी" : "Beneficiaries"}</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              {language === "hi" ? "खोज और फ़िल्टर" : "Search & Filter"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder={language === "hi" ? "योजना खोजें..." : "Search schemes..."}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={selectedState} onValueChange={setSelectedState}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {states.map((state) => (
                    <SelectItem key={state.value} value={state.value}>
                      {state.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Schemes Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-lg">{language === "hi" ? "लोड हो रहा है..." : "Loading..."}</div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSchemes.map((scheme) => (
              <Card key={scheme.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-lg leading-tight">{scheme.scheme_name}</CardTitle>
                    <Badge className={getCategoryColor(scheme.category)}>{scheme.category}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4" />
                    <span>{scheme.state}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-3">{scheme.description}</p>

                  {scheme.beneficiaries_count && (
                    <div className="flex items-center gap-2 mb-2 text-sm">
                      <Users className="h-4 w-4 text-blue-500" />
                      <span>
                        {(scheme.beneficiaries_count / 1000000).toFixed(1)}M{" "}
                        {language === "hi" ? "लाभार्थी" : "beneficiaries"}
                      </span>
                    </div>
                  )}

                  {scheme.budget_allocation && (
                    <div className="flex items-center gap-2 mb-4 text-sm">
                      <IndianRupee className="h-4 w-4 text-green-500" />
                      <span>{scheme.budget_allocation}</span>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 bg-transparent"
                          onClick={() => setSelectedScheme(scheme)}
                        >
                          <Info className="h-4 w-4 mr-2" />
                          {language === "hi" ? "विवरण" : "Details"}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="flex items-center justify-between">
                            <span>{selectedScheme?.scheme_name}</span>
                            <Badge className={getCategoryColor(selectedScheme?.category || "")}>
                              {selectedScheme?.category}
                            </Badge>
                          </DialogTitle>
                        </DialogHeader>
                        {selectedScheme && (
                          <div className="space-y-6">
                            <div>
                              <h4 className="font-semibold mb-2 flex items-center gap-2">
                                <FileText className="h-4 w-4" />
                                {language === "hi" ? "विवरण" : "Description"}
                              </h4>
                              <p className="text-gray-600">{selectedScheme.description}</p>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2 flex items-center gap-2">
                                <CheckCircle className="h-4 w-4" />
                                {language === "hi" ? "पात्रता" : "Eligibility"}
                              </h4>
                              <p className="text-gray-600">{selectedScheme.eligibility}</p>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2 flex items-center gap-2">
                                <IndianRupee className="h-4 w-4" />
                                {language === "hi" ? "लाभ" : "Benefits"}
                              </h4>
                              <p className="text-gray-600">{selectedScheme.benefits}</p>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2 flex items-center gap-2">
                                <AlertCircle className="h-4 w-4" />
                                {language === "hi" ? "आवेदन प्रक्रिया" : "Application Process"}
                              </h4>
                              <p className="text-gray-600">{selectedScheme.application_process}</p>
                            </div>

                            <div>
                              <h4 className="font-semibold mb-2 flex items-center gap-2">
                                <Phone className="h-4 w-4" />
                                {language === "hi" ? "संपर्क जानकारी" : "Contact Information"}
                              </h4>
                              <p className="text-gray-600">{selectedScheme.contact_info}</p>
                            </div>

                            {selectedScheme.website_url && (
                              <div className="pt-4 border-t">
                                <Button asChild className="w-full">
                                  <a
                                    href={selectedScheme.website_url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-2"
                                  >
                                    <ExternalLink className="h-4 w-4" />
                                    {language === "hi" ? "आधिकारिक वेबसाइट पर जाएं" : "Visit Official Website"}
                                  </a>
                                </Button>
                              </div>
                            )}
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>

                    {scheme.website_url && (
                      <Button asChild size="sm" variant="default">
                        <a href={scheme.website_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {filteredSchemes.length === 0 && !loading && (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {language === "hi" ? "कोई योजना नहीं मिली" : "No schemes found"}
            </h3>
            <p className="text-gray-600">
              {language === "hi" ? "अपने खोज मापदंड को समायोजित करने का प्रयास करें" : "Try adjusting your search criteria"}
            </p>
          </div>
        )}
      </main>
    </div>
  )
}
