"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Globe } from "lucide-react"
import { useI18n } from "@/lib/i18n/context"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()
  const { language, setLanguage, t } = useI18n()

  const navItems = [
    {
      href: "/",
      label: t("nav.home"),
    },
    {
      href: "/dashboard",
      label: t("nav.dashboard"),
    },
    {
      href: "/soil-health",
      label: t("nav.soilHealth"),
    },
    {
      href: "/disease-detection",
      label: t("nav.diseaseDetection"),
    },
    {
      href: "/encyclopedia",
      label: t("nav.encyclopedia"),
    },
    {
      href: "/weather",
      label: t("nav.weather"),
    },
    {
      href: "/market-prices",
      label: t("nav.marketPrices"),
    },
    {
      href: "/knowledge",
      label: t("nav.knowledge"),
    },
  ]

  const isActive = (href: string) => pathname === href

  const toggleLanguage = () => {
    setLanguage(language === "en" ? "hi" : "en")
  }

  return (
    <nav className="bg-white/90 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-green-600 to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AS</span>
            </div>
            <span className="text-xl font-bold text-gray-900">AgriSmart</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`text-sm font-medium transition-colors hover:text-green-600 ${
                  isActive(item.href) ? "text-green-600 border-b-2 border-green-600 pb-1" : "text-gray-700"
                }`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Language Toggle & Mobile Menu */}
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="hidden sm:flex items-center space-x-1"
            >
              <Globe className="h-4 w-4" />
              <span>{language === "en" ? "हिं" : "EN"}</span>
            </Button>

            {/* Mobile Menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="sm">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={`text-lg font-medium transition-colors hover:text-green-600 ${
                        isActive(item.href) ? "text-green-600" : "text-gray-700"
                      }`}
                    >
                      {item.label}
                    </Link>
                  ))}

                  <Button
                    variant="ghost"
                    onClick={toggleLanguage}
                    className="flex items-center space-x-2 justify-start mt-8"
                  >
                    <Globe className="h-4 w-4" />
                    <span>{language === "en" ? "Switch to Hindi" : "Switch to English"}</span>
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  )
}
