<?php
// db.php
$host = "localhost";   // MySQL host
$user = "root";        // MySQL username (default in XAMPP)
$pass = "";            // MySQL password (leave blank if none)
$dbname = "farmer_portal"; // Database name

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
