<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $land = $_POST['land'];
    $family = $_POST['family'];
    $state = $_POST['state'];
    $country = $_POST['country'];
    $mobile = $_POST['mobile'];
    $userid = $_POST['userid'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash password

    // Prepare & execute query
    $stmt = $conn->prepare("INSERT INTO farmers (name, land, family, state, country, mobile, userid, password) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdisssss", $name, $land, $family, $state, $country, $mobile, $userid, $password);

    if ($stmt->execute()) {
        echo "<h2>Registration Successful!</h2>";
        echo "<p><a href='index.html'>Click here to Login</a></p>";
    } else {
        echo "<h2>Error: " . $stmt->error . "</h2>";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid Request";
}
?>
